from django.contrib import admin

from .models import BalancesheetBackup


admin.site.register(BalancesheetBackup)
