from django.db import models

# # Create your models here.


        
# # class Pdfchatbot(models.Model):
# #     id = models.AutoField(primary_key=True)
# #     companyname = models.CharField(db_column='CompanyName', max_length=150)  # Field name made lowercase.
# #     calltype = models.CharField(db_column='CallType', max_length=150, blank=True, null=True)  # Field name made lowercase.
# #     calldate = models.DateTimeField(db_column='CallDate', blank=True, null=True)  # Field name made lowercase.
# #     parsedata = models.TextField(db_column='ParseData', blank=True, null=True)  # Field name made lowercase. This field type is a guess.
# #     pdfurl = models.CharField(db_column='PdfUrl', max_length=150)  # Field name made lowercase.

# #     class Meta:
# #         managed = False
# #         db_table = 'PdfChatbot'
        
        
        
# class DumpData(models.Model):
#     id = models.CharField(db_column='ID', max_length=500, blank=True, primary_key=True)  # Field name made lowercase.
#     datasettblname = models.CharField(db_column='DataSetTblName', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     uniquekey = models.CharField(db_column='UniqueKey', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     clientid = models.CharField(db_column='ClientID', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     familyid = models.CharField(db_column='FamilyID', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     advisorid = models.CharField(db_column='AdvisorID', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     assetid = models.CharField(db_column='AssetId', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     instrumenttypeid = models.CharField(db_column='InstrumentTypeId', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     instrumentname = models.CharField(db_column='InstrumentName', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     isinno = models.CharField(db_column='ISINNo', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     foliono = models.CharField(db_column='FolioNo', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     units = models.CharField(db_column='Units', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     marketprice = models.CharField(db_column='MarketPrice', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     marketvalue = models.CharField(db_column='MarketValue', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     s_code = models.CharField(db_column='S_Code', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     amficode = models.CharField(db_column='AMFICODE', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     scripcode = models.CharField(db_column='Scripcode', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     exceltype = models.CharField(db_column='excelType', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     nameofholder = models.CharField(db_column='NameOfHolder', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     nameofholder_mf = models.CharField(db_column='NameOfHolder_MF', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     anualizedreturn = models.CharField(db_column='AnualizedReturn', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     avgcost = models.CharField(db_column='AvgCost', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     couponrate = models.CharField(db_column='CouponRate', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     dpclientid = models.CharField(db_column='DPClientID', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     earmarked = models.CharField(db_column='EarMarked', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     facevalue = models.CharField(db_column='FaceValue', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     lent = models.CharField(db_column='Lent', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     locked_in = models.CharField(db_column='Locked_In', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     maturitydate = models.CharField(db_column='MaturityDate', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     pledgesetup = models.CharField(db_column='PledgeSetup', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     pledged = models.CharField(db_column='Pledged', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     pledgee_bal = models.CharField(db_column='Pledgee_Bal', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     safekeep = models.CharField(db_column='SafeKeep', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     symbol = models.CharField(db_column='Symbol', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     totalcost = models.CharField(db_column='TotalCost', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     ucc = models.CharField(db_column='UCC', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     unrealizedpl = models.CharField(db_column='UnrealizedPL', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     free_bal = models.CharField(db_column='Free_Bal', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     cumulative = models.CharField(db_column='Cumulative', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     frozen_bal = models.CharField(db_column='Frozen_bal', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     holdingp = models.CharField(db_column='HoldingP', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     pledgee_bal_cdsl = models.CharField(db_column='Pledgee_Bal_CDSL', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     asondates = models.CharField(db_column='AsOnDates', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     navdate = models.CharField(db_column='NavDate', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     registrar = models.CharField(db_column='Registrar', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     doe = models.CharField(db_column='DOE', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     casfilename = models.CharField(db_column='CASFileName', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     castype = models.CharField(db_column='CASType', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     mappedlevel = models.CharField(db_column='MappedLevel', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     mappedwith = models.CharField(db_column='MappedWith', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     fromdate = models.CharField(db_column='FromDate', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     todate = models.CharField(db_column='ToDate', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     mfholdingtype = models.CharField(db_column='MFHoldingType', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     issuccess = models.CharField(db_column='IsSuccess', max_length=500, blank=True, null=True)  # Field name made lowercase.
#     entryby = models.CharField(db_column='EntryBy', max_length=500, blank=True, null=True)  # Field name made lowercase.

#     class Meta:
#         managed = False
#         db_table = 'Dump_Data'
        

        
        
class BalancesheetBackup(models.Model):

    company_code = models.IntegerField(db_column='COMPANY_CODE')  # Field name made lowercase.
    year_end = models.IntegerField(db_column='Year_end')  # Field name made lowercase.
    type = models.CharField(db_column='TYPE', max_length=1, db_collation='SQL_Latin1_General_CP1_CI_AS')  # Field name made lowercase.
    company_name = models.CharField(db_column='Company_name', max_length=255, db_collation='SQL_Latin1_General_CP1_CI_AS', blank=True, null=True)  # Field name made lowercase.
    no_months = models.IntegerField(db_column='No_Months', blank=True, null=True)  # Field name made lowercase.
    yrc = models.IntegerField(db_column='YRC', blank=True, null=True)  # Field name made lowercase.
    main_unit = models.CharField(db_column='Main_Unit', max_length=50, db_collation='SQL_Latin1_General_CP1_CI_AS', blank=True, null=True)  # Field name made lowercase.
    share_capital = models.FloatField(db_column='Share_capital', blank=True, null=True)  # Field name made lowercase.
    equity_iss = models.FloatField(db_column='Equity_Iss', blank=True, null=True)  # Field name made lowercase.
    equity_paidup = models.FloatField(db_column='Equity_paidup', blank=True, null=True)  # Field name made lowercase.
    adj_equity = models.FloatField(db_column='Adj_Equity', blank=True, null=True)  # Field name made lowercase.
    pref_capital = models.FloatField(db_column='Pref_capital', blank=True, null=True)  # Field name made lowercase.
    face_value = models.FloatField(db_column='Face_value', blank=True, null=True)  # Field name made lowercase.
    no_equity_paidup = models.FloatField(db_column='No_equity_paidup', blank=True, null=True)  # Field name made lowercase.
    no_equity_subscribed = models.FloatField(db_column='No_Equity_Subscribed', blank=True, null=True)  # Field name made lowercase.
    equity_subscribed = models.FloatField(db_column='Equity_subscribed', blank=True, null=True)  # Field name made lowercase.
    equity_callup = models.FloatField(db_column='Equity_CallUp', blank=True, null=True)  # Field name made lowercase.
    resrv_surp = models.FloatField(db_column='Resrv_Surp', blank=True, null=True)  # Field name made lowercase.
    share_premium = models.FloatField(db_column='Share_premium', blank=True, null=True)  # Field name made lowercase.
    capital_reserve = models.FloatField(db_column='Capital_reserve', blank=True, null=True)  # Field name made lowercase.
    profit_loss = models.FloatField(db_column='Profit_Loss', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Balancesheet_backup'