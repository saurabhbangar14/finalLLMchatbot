import io
import PyPDF2
# from django.contrib.auth.models import User
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
import os
import re
from langchain.text_splitter import LatexTextSplitter
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain import HuggingFaceHub
from django.core.files.storage import default_storage
from langchain.llms import AI21

from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required

from django.views.decorators.clickjacking import xframe_options_exempt

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login

from langchain_experimental.sql import SQLDatabaseChain


#Similar words




# from langchain.chains import create_sql_query_chain

# os.environ['HUGGINGFACEHUB_API_TOKEN'] = "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" 
os.environ['AI21_API_KEY'] = "RjUqYvXeyaTrHBC0staob6GB35pca9b4"
vector_list=[]
questions=[]
answers=[]
questions_dbt=[]
answers_dbt=[]

import pyodbc
from sqlalchemy.engine import URL
from langchain import  SQLDatabase 
# from langchain_experimental.sql import SQLDatabaseChain
from langchain.chains import create_sql_query_chain

from langchain.agents import create_sql_agent
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from langchain.agents.agent_types import AgentType
from llama_index.llms import OpenAI
import openai
from collections import Counter
import time

# os.environ['HUGGINGFACEHUB_API_TOKEN'] = "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"
os.environ['AI21_API_KEY'] = "hJUk8T7hZch5W92MKe7JAKnpysjoILgt"# mazya sathis key aahe
# os.environ['AI21_API_KEY'] = "Fr3hjkV0CRp9yvRRYV7OjNRtDqPBaStJ"# Ma'am La key Send keli aahe 

# os.environ['OPENAI_API_KEY'] = "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"
# openai.api_key = os.environ.get('OPENAI_API_KEY')

vector_list=[]
Questions_pdf=[]
Answer_pdf=[]
Questions_database=[]
Answer_database=[]
pdf_text_data=''
file_url=''
file_name=''
file=''
user_selected_companys=[]




# connection_url = URL.create(
#     "mssql",
#     username='traineeuser',
#     password='Tra!nee$0107',
#     host='10.20.50.117',
#     port=1433,
#     database="TraineeData",
#     query={
#         "driver": "ODBC Driver 17 for SQL Server",
#     },
# )















connection_url = URL.create(
        "postgresql+psycopg2",
        username='postgres',
        password='admin123',
        host='localhost',
        port=5432,
        database="postgres",
    )



def Home(request):
    return render(request,'base.html')



def Admin_before(request):

    return render(request,'admin.html')
def database_before(request):
    Answer_database.clear()
    Questions_database.clear()
    return render(request,'databaseChatBot.html')
def Client_before(request):
    vector_list.clear()
    Questions_pdf.clear()
    Answer_pdf.clear()
    return render(request,'client.html')    

def get_company(request):
    company=request.POST.get('company')
    company=str(company).upper()
    # print("==========",company)
    all_company=[]
    sql_query=""
    if company != None:
        sql_query=f"SELECT COMPANY FROM company_master where COMPANY LIKE '{company}%'"
        # print("==================",sql_query)
        db = SQLDatabase.from_uri(connection_url,include_tables=['company_master'],sample_rows_in_table_info=0)
        tem_all_company=db.run(sql_query)

        tem_all_company=tem_all_company.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
        tem_all_company=tem_all_company.replace("Decimal","").replace("\'","").split(",")
        if len(tem_all_company[-1])==0:
            tem_all_company.pop(-1)
        all_company = [item.lstrip() for item in tem_all_company]
        all_company=sorted(all_company)
        # print("--------",all_company)
    # return render(request,'databaseChatBot.html',{"all_company":all_company})
    return JsonResponse({"all_company":all_company}) 


def Admin_after(request):
    
    filedata = request.FILES['files1'].read()
    companyName=request.POST.get('CompanyName')
    callType=request.POST['callType']

    vectoename=companyName+"_"+callType
    # file_name = default_storage.save(filedata1.name, filedata1)
    # print("\n****************",file_name)
    pdfReader = PyPDF2.PdfReader(io.BytesIO(filedata))
    no_of_pages =len(pdfReader.pages)  
   
 
    text_data=''
    for i in range(no_of_pages):
            pageObj = pdfReader.pages[i]
            text_data+= pageObj.extract_text()

                                            # separator = "\n"
    text_splitter = LatexTextSplitter(chunk_size = 256,chunk_overlap  = 10,length_function = len)
  

    texts = text_splitter.split_text(text_data)
    embeddings = HuggingFaceEmbeddings()

    vectoestore = FAISS.from_texts(texts, embeddings)
    vectoestore.save_local(vectoename)


    # Pdfchatbot.objects.create(companyname=companyName,calltype=callType,parsedata=text_data)

    return render(request,'admin.html',{"data":text_data})


def get_vector(request):

    filedata = request.FILES['files1'].read()
    filepath = request.FILES['files1']

    pdfReader = PyPDF2.PdfReader(io.BytesIO(filedata))
  
    no_of_pages =len(pdfReader.pages)  
   
 
    text_data=''
    for i in range(no_of_pages):
            pageObj = pdfReader.pages[i]
            text_data+= pageObj.extract_text()


                                            # separator = "\n"
    text_splitter = LatexTextSplitter(chunk_size = 200,chunk_overlap  = 10,length_function = len)

    texts = text_splitter.split_text(text_data)

    embeddings = HuggingFaceEmbeddings()

    vectoestore = FAISS.from_texts(texts, embeddings)

    # vectoestore.save_local(vectoename)

    # vectoename=companyName+"_"+callType
    filename="/media/"+str(filepath)
    # print("//////////////////",filename)
    embeddings = HuggingFaceEmbeddings()
    # vectoestore=FAISS.load_local(filedata, embeddings)
    vector_list.append(vectoestore) 
    
    # pdf_text_data = DumpData.objects.all().values()
    # print("************",pdf_text_data)
    print("Done !!!!!!!!!!!!!!!!!!")
    return render(request,'client.html',{"file_url":filename}) 




def Client_after(request):
    # print("3333333333#############Client_after")
    query=request.POST.get('question') 
    try:
        vectoestore=vector_list[0]
        llm = AI21(temperature=0.5)
        chain = load_qa_chain(llm, chain_type="stuff") 

        # print("---------",query)       
        doc = vectoestore.similarity_search(str(query))
        query_answer=chain.run(input_documents = doc,question=query)
        if(query==""):
            query_answer="Error1 : Plz Enter Some Questions..."
    except:
        query_answer="Plz Select Company And it's Call Type First"

        # Questions.append("Questions: "+query) 

    # llm = HuggingFaceHub( repo_id= "google/flan-t5-xxl" , model_kwargs={"temperature": 0.5, "max_length": 1000} )

    # Questions.append(query_answer)
    Questions_pdf.append(query) 

    # print("/////////////////",query_answer)
        # line="------------------------------------------------------------------------------"
    Answer_pdf.append(query_answer)
    # Questions.append(line)
    # print("***********",Questions)
    # print("/////////////////",Answer)
    return JsonResponse({"questions":Questions_pdf,"answers":Answer_pdf}) 
    # return render(request,'client.html',{"file_url":filename,"Questions":Questions})
    # return render(request,'client.html',{"Questions":Questions,"Answer":Answer})






#     Key_words=["ADD"	,"ADD" "CONSTRAINT"	,"ALTER"	,"ALTER" "COLUMN"	,"ALTER TABLE"	,"ALL"	,"AND"	,"ANY"	,"AS"	,"ASC"	,"BETWEEN"	,"CASE"	,
#                 "CHECK"	,"COLUMN"	,"CONSTRAINT","CREATE" "DATABASE"	,"CREATE INDEX"	,"CREATE OR REPLACE VIEW",	"CREATE TABLE"	,"CREATE TABLE AS",
#                 "CREATE UNIQUE INDEX"	,"CREATE VIEW"	,"CROSS JOIN"	,"DEFAULT"	,"DELETE"	,"DESC"	,"DISTINCT","DROP"	,"DROP COLUMN	",
#                 "DROP CONSTRAINT"	,"DROP DATABASE"	,"DROP DEFAULT	","DROP INDEX"	,"DROP TABLE"	,"DROP VIEW"	,"EXCEPT"	,"EXISTS"	,
#                 "FOREIGN KEY"	,"FROM"	,"FULL JOIN"	,"FULL OUTER JOIN"	,"GROUP BY"	,"HAVING"	,"LIKE"	,"IN"	,"INDEX"	,"INNER JOIN"	,"INSERT INTO",
#                 "INSERT INTO SELECT","INTERSECT"	,"IS NULL"	,"IS NOT NULL"	,"JOIN"	,"LEFT JOIN"	,"LEFT OUTER JOIN"	,"LIKE	",
#                 "LIMIT"	,"NOT"	,"NOT LIKE","NOT LIKE","NOT NULL","OR"	,"ORDER BY","PRIMARY KEY","RIGHT JOIN"	,"RIGHT OUTER JOIN","SELECT"	,
#                "SELECT DISTINCT","SELECT INTO","SELECT LIMIT","SET"	,"SOME"	,"TRUNCATE TABLE","UNION"	,"UNION ALL","UNIQUE","UPDATE"	,
#                 "VALUES"	,"VIEW"	,"WHERE","="]


# (?<==)\W*"([^%"]*)"


def run_query(table,SQL_query):
    db = SQLDatabase.from_uri(connection_url,include_tables=[table],sample_rows_in_table_info=0)
    tem_var=db.run(SQL_query)
    tem_var=tem_var.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
    return tem_var.replace("Decimal","").replace(",","").replace("\"","").replace("\'","")
    
    
# similar_words_to_lowest
# similar_words_to_highest
def get_answar_in_list(ans):
    ans=ans.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
    ans=ans.replace("Decimal","").replace("\"","").replace("\'","")
    ans=ans.split(",")
    if len(ans[-1])==0:
        ans.pop(-1)
    ans = [item.lstrip() for item in ans]
    return ans
    

def error_function(error,query):
    questions_dbt.append(query)                
    # query_answer=get_query_ans(str(table).replace("[","").replace("]","").replace("'",""),query)
    answers_dbt.append(error)
    return JsonResponse({"questions":questions_dbt,"answers":answers_dbt}) 
    


def database_after(request):
    # db = SQLDatabase.from_uri(connection_url,include_tables=['balancesheet_company'])
    
    start_time = time.time()
    Coloum_Name=[]
    Coloum_Name_AND_Table=[]
    Table_name_for_coloum=[]
    Keys_With_Tables=[]
    Value_AND_Table=[]
    Table_name_for_value=[]
    query_answer=""
    #Similar words
    # similar_words_to_highest = ["high","highest","Tallest","latest","last","Supreme", "Peak", "Apex", "Pinnacle", "Summit", "Zenith", "Culmination", "Utmost", "Paramount", "Superior", "Topmost", "Maximum", "Eminent", "Preeminent", "Ultimate", "Uppermost", "Sovereign", "Greatest", "Superlative", "Acme", "Climax", "Optimum", "Record-breaking", "Unsurpassed","Tall", "Elevated", "Towering", "Lofty", "Upward", "Sky-high", "Exalted", "Grand", "Elevated", "Raised", "High-reaching", "Ascending", "Overhead", "Top", "Superior", "Prominent", "Noble", "Superior", "Mighty", "Majestic", "Altitudinous", "Stature", "Altitude", "Hilly", "Alpine"]


    # similar_words_to_lowest = ["low","lowest","Bottom", "Minimum", "first","Least", "Smallest", "Nadir", "Base", "Lowermost", "Worst", "Weakest", "Inferior", "Subpar", "Undermost", "Cheapest", "Shallowest", "Least favorable", "Rock-bottom", "Substandard", "Worst-case", "Poorest", "Most inferior", "Least significant", "Least important","Reduced", "Diminished", "Lowered", "Decreased", "Minimal", "Subdued", "Depleted", "Inferior", "Under", "Short", "Small", "Modest", "Depressed", "Dim", "Dropped", "Base", "Scant", "Slight", "Limited", "Diminutive", "Scanty", "Weak", "Diminished", "Insignificant", "Muted"]
    similar_words= ["HIGH","SUM","AVG","AVERAGE","HIGHEST","LATEST","latest","COUNT","LAST","FIRST","LOW","LOWEST","REDUCED", "DIMINISHED", "LOWERED", "DECREASED", "MINIMAL", "SUBDUED", "DEPLETED", "INFERIOR", "UNDER", "SHORT", "SMALL", "MODEST", "DEPRESSED", "DIM", "DROPPED", "BASE", "SCANT", "SLIGHT", "LIMITED", "DIMINUTIVE", "SCANTY", "WEAK", "DIMINISHED", "INSIGNIFICANT", "MUTED","BOTTOM", "MINIMUM", "LEAST", "SMALLEST", "NADIR", "BASE", "LOWERMOST", "WORST", "WEAKEST", "INFERIOR", "SUBPAR", "UNDERMOST", "CHEAPEST", "SHALLOWEST", "LEAST FAVORABLE", "ROCK-BOTTOM", "SUBSTANDARD", "WORST-CASE", "POOREST", "MOST INFERIOR", "LEAST SIGNIFICANT", "LEAST IMPORTANT","TALL", "ELEVATED", "TOWERING", "LOFTY", "UPWARD", "SKY-HIGH", "EXALTED", "GRAND", "ELEVATED", "RAISED", "HIGH-REACHING", "ASCENDING", "OVERHEAD", "TOP", "SUPERIOR", "PROMINENT", "NOBLE", "SUPERIOR", "MIGHTY", "MAJESTIC", "ALTITUDINOUS", "STATURE", "ALTITUDE", "HILLY", "ALPINE","TALLEST", "SUPREME", "PEAK", "APEX", "PINNACLE", "SUMMIT", "ZENITH", "CULMINATION", "UTMOST", "PARAMOUNT", "SUPERIOR", "TOPMOST", "MAXIMUM", "EMINENT", "PREEMINENT", "ULTIMATE", "UPPERMOST", "SOVEREIGN", "GREATEST", "SUPERLATIVE", "ACME", "CLIMAX", "OPTIMUM", "RECORD-BREAKING", "UNSURPASSED"]
    

    
    # db = SQLDatabase.from_uri("sqlite:///trainee_database.db",include_tables=['Company_Master','sheet'])#,'Company_Master','Balancesheet_backup'
    # llm = AI21(temperature=0.1)
    db = SQLDatabase.from_uri(connection_url,sample_rows_in_table_info=0)#'balancesheet_backup',,include_tables=['company_master']
    query=request.POST.get('question')
    company=request.POST.get('company')
    get_companyCode_of_select_company=[]
    # company="adsd"
    if len(company)!=0:
        company=company.replace("\"","").replace("\'","")
        sql_query=f"SELECT COMPANY_CODE from company_master where COMPANY ='{company}'"
        get_companyCode_of_select_company_1=db.run(sql_query)
        # get_companyCode_of_select_company_1='100209'
        # print("==================",get_companyCode_of_select_company_1)
        # print("==================",sql_query)
        if len(get_companyCode_of_select_company_1)!=0:
            get_companyCode_of_select_company.append('company_master')
            tem_var=get_answar_in_list(get_companyCode_of_select_company_1)
            try:
                get_companyCode_of_select_company.append(tem_var[-1])
            except:
                # query_answer="Convert All Company Name In Upper Case in Company Master Table.."
                query_answer="ERROR2..."
                error_function(query_answer,query)
        else:
            query_answer="ERROR23... Company code Not found in database"
            questions_dbt.append(query)                
            # query_answer=get_query_ans(str(table).replace("[","").replace("]","").replace("'",""),query)
            answers_dbt.append(query_answer)
            return JsonResponse({"questions":questions_dbt,"answers":answers_dbt}) 
            
   
    print("\n\n>>>>>>>>>>>>>>>>",query)
    print("\n\n>>>>>>>>>>>>>>>>",company)
    print("\n\n>>>>>>>>>>>>>>>>",get_companyCode_of_select_company)
    
    query1=query
    query=query.replace("?"," ")
    query=query.upper()
    item=""
    cropList = ["IN THIS COMPANY","IN THE GIVEN COMPANY","IN THE PROVIDED COMPANY","IN COMPANY","IN THE COMPANY","OF THE CPMPANY","OF THIS COMPANY"]
    if any(item in query for item in cropList):
        item = [item for item in cropList if item in query]
    for i in item:
        query = str(query).replace(i,"").strip()
    compList = ["WHICH COMPANIES","WHICH COMPANY"]
    if any(item in query for item in compList):
        item = [item for item in compList if item in query]
        for i in item:
            query = str(query).replace(i,"WHICH PEER GROUPS").strip()  
    Flag_for_YearOnYearPercentageOf=False
    Flag_for_IndustryPeers=False
    Flag_for_housePeers=False
    pattern_1 = r"YEAR\s+ON\s+YEAR\s+PERCENTAGE\s+OF"
    pattern_12 = r'\bGROWTH\b'
    pattern_123 = r'\bPEERS\sGROUP\b'
    pattern_2 = r"INDUSTRY\s+PEERS"
    pattern_3 = r"HOUSE\s+PEERS"
    growth_flag=False
    peers_group_flag=False
    countWord_index=-1
    AllWord_index=-1
    UpperCasequery1=str(query).replace(","," ").upper()
    seperated_By_Space_for_Coloum_search=UpperCasequery1.split(" ")
    # Check if the pattern is present in the text
    if re.search(pattern_1, str(query).upper(), re.IGNORECASE):
        Flag_for_YearOnYearPercentageOf=True
    if re.search(pattern_12, str(query).upper(), re.IGNORECASE):
        # print("-=-=-=-=-=-=-=-=-=-")
        growth_flag=True
        Flag_for_YearOnYearPercentageOf=True

        
    if re.search(pattern_123, str(query).upper(), re.IGNORECASE):
        peers_group_flag=True
        # print("****")
        try:
            AllWord_index=seperated_By_Space_for_Coloum_search.index('ALL')
        except:
            pass
        try:
            countWord_index=seperated_By_Space_for_Coloum_search.index('COUNT')
        except:
            pass
        # print("+++++++++++++++++++++++++++++++++sdkfksgskgsdk")
            
        
    if re.search(pattern_3, str(query).upper(), re.IGNORECASE):
        Flag_for_housePeers=True
        print("-------------")
        try:
            countWord_index=seperated_By_Space_for_Coloum_search.index('COUNT')
        except:
            pass
        try:
            AllWord_index=seperated_By_Space_for_Coloum_search.index('ALL')
        except:
            pass
    if re.search(pattern_2, str(query).upper(), re.IGNORECASE):
        Flag_for_IndustryPeers=True
        # print("-------------")
        try:
            countWord_index=seperated_By_Space_for_Coloum_search.index('COUNT')
        except:
            pass
        try:
            AllWord_index=seperated_By_Space_for_Coloum_search.index('ALL')
        except:
            pass
        # query=str(query).upper()
        # query=query.replace("WHAT IS ","GIVE")
        # query=query.replace("WHAT IS","GIVE")
        # query = re.sub(pattern,"", query)
        # split_By_Space=query.split(" ")
        # query=""
        # for i in range(len(split_By_Space)):
        #     if split_By_Space[i].isdigit():
        #         temp_var="Year "+split_By_Space[i]
        #         split_By_Space[i]=temp_var
        #     query=query+split_By_Space[i]+" "
        #     # "GIVE Year 202303 FOR EQUITY PAIDUP OF INFOSYS WHOSE TYPE IS S"
        #     # query="GIVE EQUITY PAIDUP OF INFOSYS WHOSE TYPE IS S FOR Year 202303 "
        # print("\n\n--------------------------",query)
        
        
                
                
                
            
    # print("\n\n--------------------------",query)
    # print("\n\n--------------------------",split_By_Space)
        
    UpperCasequery1=str(query).replace(","," ").upper()
    # print("\n\n--------------------------",UpperCasequery1)
    seperated_By_Space_for_Coloum_search=UpperCasequery1.split(" ")
    seperated_By_Space=UpperCasequery1.split(" ") 

    table=db.get_usable_table_names()

    # print("-------------------------",table)

    
    
    
    
    # table=db._all_tables
    # print(">>>>>>>>>>>>>>>>",table)
    ignor_words=['IS','OF','NO']
    ignor_KEY_Words=['PRIMARY KEY','FOREIGN KEY','REFERENCES']
    
    seperated_By_Space_use=UpperCasequery1.split(" ")
    seperated_By_Space_for_Value_search=UpperCasequery1.split(" ")  
    
    # for k in table:
    # print("///////////////////",seperated_By_Space_for_Coloum_search)
    Number_value_check_flag=True
    text_value_check_flag=True
    where_condition_var=""
    tem_store_value=""
    tem_store_coloum=""
    tem_Value_AND_Table=[]
    Value_AND_Table=[]
    similar_word_array=[]
    tem_length_For_Coloum_Identification=1 
    # seperated_By_Space_for_Coloum_search=UpperCasequery1.split(" ")
    
    
    valueText=[]
    
    for k in table:
        temp_array_for_Key=[]
        FOREIGN_key_of_table=[]
        db = SQLDatabase.from_uri(connection_url,include_tables=[k],sample_rows_in_table_info=0)
        seperated_By_Space_for_Coloum_search=UpperCasequery1.split(" ")
        
        
        
        
        #To Get primary Keys
        # print("\n\n----------------",k)
        # print("\n\n-------------------------",db.get_table_info())
        F_key_table = re.findall(r'\bREFERENCES\s+(\w+)\s+\(',db.get_table_info()) 
        Keys1 = re.findall(r'(?<=PRIMARY KEY)\W*([^")]*)',db.get_table_info()) 
        Keys1=str(Keys1).replace("[","").replace("]","").replace("\'","")
        Keys1=str(Keys1).split(",")
        temp_array_for_Key.append(k)
        if len(Keys1)!=0:
            for i in Keys1:
                temp_array_for_Key.append(str(i).strip())
            temp_array_for_Key.append(1)
            Keys_With_Tables.append(temp_array_for_Key)
        
        
        # Keys2 = re.findall(r'(?<=FOREIGN KEY)\W*([^")]*)',db.get_table_info()) 
        # Keys2=str(Keys2).replace("[","").replace("]","").replace("\'","")
        # Keys2=str(Keys2).split(",")
        
        # if len(Keys2)!=0:
        #     for i in Keys2:
        #         FOREIGN_key_of_table.append(str(i).strip().upper())

        
        

                    
            
        
        
        
        # print("\n\n----------------Keys_With_Tables",Keys_With_Tables)
        # print("\n\n----------------FOREIGN_key_of_table",FOREIGN_key_of_table)
         
        quer3="SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '"+k+"\'"
        tem_var1=db.run(quer3)
        tem_var1=tem_var1.replace("(","").replace(",)","").replace("\'","").replace("[","").replace("]","").strip()
        tem_var1=tem_var1.split(",")
        # for j in range(len(FOREIGN_key_of_table)):
        for i in tem_var1:
            # if i.strip().upper()!=FOREIGN_key_of_table[j]:
            Coloum_Name.append(i.strip().upper())


         
        temp_Array_for_coloum_name=[]  
        # print("////////////////////Coloum_Name",Coloum_Name)
        
        
        
        
        #===================================================================================================================================
        #To Search Coloum Name from Query 
        # print("##############################################",seperated_By_Space_for_Coloum_search)
        for i in range(len(Coloum_Name)):
            tem_var=Coloum_Name[i].split("_")
            
            
            if len(tem_var)==1:
                # print("\n\n////////////////////////////tem_var  1  ",tem_var)
                try:
                    first=seperated_By_Space_for_Coloum_search.index(tem_var[0])
                    # print("\n\n==================================",first)
                    Coloum_Name_AND_Table.append(k)
                    Coloum_Name_AND_Table.append(Coloum_Name[i])
                    seperated_By_Space_for_Coloum_search[first]=""
                    # print("\n\n==================================1",tem_var)
                    Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
                    tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
                except:
                    pass
            else:
                try:

                    for j in range(len(tem_var)):
                        # print("1",tem_var[j])
                        first=seperated_By_Space_for_Coloum_search.index(tem_var[0])
                        last=seperated_By_Space_for_Coloum_search.index(tem_var[-1])
                        seperated_By_Space_for_Coloum_search.index(tem_var[-2])# to check "call" also for condition is ("equity_paid_up", "equity_call_up")  for this it is use
                    for p in range(first,last+1):
                        seperated_By_Space_for_Coloum_search[p]=""
                    # print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$seperated_By_Space_for_Coloum_search       ",seperated_By_Space_for_Coloum_search)           
                    Coloum_Name_AND_Table.append(k)
                    tem_Coloum_Name=seperated_By_Space_for_Coloum_search[first-1]+"_"+Coloum_Name[i] #for "NO_EQUITY_PAID_UP" and "EQUITY_PAID_UP" 
                    # tem_Coloum_Name_2=seperated_By_Space_for_Coloum_search[first]+"_"+Coloum_Name[i] #for "NO_EQUITY_PAID_UP" and "EQUITY_PAID_UP" 
                    if tem_Coloum_Name in Coloum_Name:
                        Coloum_Name_AND_Table.append(tem_Coloum_Name)
                        # print("\n\n==================================2",tem_Coloum_Name)
                    else:
                        Coloum_Name_AND_Table.append(Coloum_Name[i])
                        # print("\n\n==================================2",Coloum_Name[i])
                    
                    
                    Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
                    tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
                except:
                    pass

                    
        
        # print("\$$$$$$$$$$$$$$$$$$$$$$$$$Coloum_Name_AND_Table",Coloum_Name_AND_Table)            
                        
                
        
        
        # for i in range(len(seperated_By_Space_for_Coloum_search)):
        #     # print("Inside iF -----",seperated_By_Space_for_Coloum_search[i])
        #     if seperated_By_Space_for_Coloum_search[i] in str(Coloum_Name):
        #         # print("Inside iF ",seperated_By_Space_for_Coloum_search[i])
        #         for j in range(len(Coloum_Name)):
        #             if seperated_By_Space_for_Coloum_search[i]==Coloum_Name[j]:
        #                 # print("\n\n--------------*********1",Coloum_Name[j])
        #                 Coloum_Name_AND_Table.append(k)
        #                 Coloum_Name_AND_Table.append(Coloum_Name[j])
        #                 Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
        #                 tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
        #                 seperated_By_Space_for_Coloum_search[i]=" "
        #             else:
        #                 # print("Inside iF ",seperated_By_Space_for_Coloum_search[i])
        #                 if i <=len(seperated_By_Space_for_Coloum_search)-3:
        #                     tem_var=seperated_By_Space_for_Coloum_search[i]+"_"+seperated_By_Space_for_Coloum_search[i+1]
        #                     if tem_var==Coloum_Name[j]:
        #                         length1=0
        #                         To_check_previous_Word=seperated_By_Space_for_Coloum_search[i-1]+"_"+seperated_By_Space_for_Coloum_search[i]+"_"+seperated_By_Space_for_Coloum_search[i+1]
        #                         # print("\n\n--------------*********To_check_previous_Word2",To_check_previous_Word)
        #                         for l in range(len(Coloum_Name)):
        #                             if To_check_previous_Word==Coloum_Name[l]:
        #                                 length1=1
        #                                 break
        #                         if length1==0: 
        #                             # print("\n\n--------------*********3",Coloum_Name[j])
        #                             Coloum_Name_AND_Table.append(k)
        #                             Coloum_Name_AND_Table.append(Coloum_Name[j])
        #                             Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
        #                             tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
        #                             # Table_name_for_coloum.append(k)
        #                             seperated_By_Space_for_Coloum_search[i]=" "
        #                             seperated_By_Space_for_Coloum_search[i+1]=" "
        #                     else:
        #                         try:
        #                             tem_var=seperated_By_Space_for_Coloum_search[i]+"_"+seperated_By_Space_for_Coloum_search[i+1]+"_"+seperated_By_Space_for_Coloum_search[i+2]
        #                             if tem_var==Coloum_Name[j]:
        #                                 # print("\n\n--------------*********4",tem_var)
        #                                 Coloum_Name_AND_Table.append(k)
        #                                 Coloum_Name_AND_Table.append(Coloum_Name[j])
        #                                 # Table_name_for_coloum.append(k)
        #                                 Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
        #                                 tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
        #                                 seperated_By_Space_for_Coloum_search[i]=" "
        #                                 seperated_By_Space_for_Coloum_search[i+1]=" "
        #                                 seperated_By_Space_for_Coloum_search[i+2]=" "
        #                         except:
        #                             raise("Index OUT Of Range will searching Coloum Name")
        #                 else:
        #                     if i <=len(seperated_By_Space_for_Coloum_search)-2:
        #                         tem_var=seperated_By_Space_for_Coloum_search[i]+"_"+seperated_By_Space_for_Coloum_search[i+1]
        #                         if tem_var==Coloum_Name[j]:
        #                             # print("\n\n--------------*********5",tem_var)
        #                             Coloum_Name_AND_Table.append(k)
        #                             Coloum_Name_AND_Table.append(Coloum_Name[j])
        #                             Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
        #                             tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
        #                             # Table_name_for_coloum.append(k)
        #                             seperated_By_Space_for_Coloum_search[i]=" "
        #                         else:
        #                             tem_var=seperated_By_Space_for_Coloum_search[i]
        #                             if tem_var==Coloum_Name[j]:
        #                                 # print("\n\n--------------*********5",tem_var)
        #                                 Coloum_Name_AND_Table.append(k)
        #                                 Coloum_Name_AND_Table.append(Coloum_Name[j])
        #                                 Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
        #                                 tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
        #                                 # Table_name_for_coloum.append(k)
        #                                 seperated_By_Space_for_Coloum_search[i]=" "
      


        
        
            
            
            
        #===================================================================================================================================   
            
         # To get Number values from query   
        # if Number_value_check_flag==True:
        if len(Coloum_Name_AND_Table)!=0:
            temp_value_NUMBER_with_table=[]
            # print("\n\n\n===================Coloum_Name_AND_Table",Coloum_Name_AND_Table)   
            if growth_flag==True:
                if 'YEAR' in Coloum_Name:
                    Coloum_Name_AND_Table.append(k)
                    Coloum_Name_AND_Table.append('YEAR')
                    Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
                    tem_length_For_Coloum_Identification = tem_length_For_Coloum_Identification+1
            for i in range(len(seperated_By_Space_for_Value_search)):
                if seperated_By_Space_for_Value_search[i].isdigit():
                    if Flag_for_YearOnYearPercentageOf==True:
                        if seperated_By_Space_for_Value_search[i-1]!="YEAR":
                            seperated_By_Space_for_Value_search[i-1]="YEAR"
                    # print("\n\n\n===================seperated_By_Space_for_Value_search",seperated_By_Space_for_Value_search)         
                    for j in range(1,len(Coloum_Name_AND_Table),3):

                            # print("-=-=-=-=-=-=-=-==-=-=-=-=-=--=-=-Coloum_Name_AND_Table",Coloum_Name_AND_Table[j])
                        # for jk in range(1,len(Coloum_Name_AND_Table[j]),2):
                            # print("-=-=-=-=-=-=-=-==-=-=-=-=-=--=-=-",Coloum_Name_AND_Table[j][jk])
                            tem_coloum_name=str(Coloum_Name_AND_Table[j]).split("_")
                            
                            for p in range(len(tem_coloum_name)-1,-1,-1):
                                # print("-=-=-=-=-=-=-=-==-=-=-=-=-=--=-=-tem_coloum_name",tem_coloum_name[p])
                                # print("-=-=-=-=-=-=-=-==-=-=-=-=-=--=-=-seperated_By_Space_for_Value_search",seperated_By_Space_for_Value_search[i-1])
                                
                                if len(tem_coloum_name)==1:# this condition is for if coloum name has one word then
                                    
                                    if tem_coloum_name[p]==seperated_By_Space_for_Value_search[i-1]:# share 521 then true
                                        # print("1")
                                        try:
                                            tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                            # print("********",tem_var)
                                            if len(tem_var)!=0:
                                                tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                tem_Value_AND_Table.append(k)
                                                # Table_name_for_value.append(k)
                                        # where_condition_var=
                                            break
                                        except:
                                            pass
                                    else:# share of(any word like 'for') 521 then true
                                        if tem_coloum_name[p]==seperated_By_Space_for_Value_search[i-2]:
                                            # print("2")
                                            try:
                                                tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                                # print("********",tem_var)
                                                if len(tem_var)!=0:
                                                    tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                    tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                    tem_Value_AND_Table.append(k)
                                                    # Table_name_for_value.append(k)
                                                # where_condition_var=
                                                break
                                            except:
                                                pass
                                else:# this condition is for if coloum name has more then one word then work like tem_coloum_name=['share','capital']
                                    if tem_coloum_name[p]==seperated_By_Space_for_Value_search[i-1]:#share capital (of any word not present) 521 then true in this it check first "capital"
                                        if tem_coloum_name[p-1]==seperated_By_Space_for_Value_search[i-2]:# if "capital" present then "share" also check 
                                            # print("3")
                                            try:
                                                tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                                # print("********",tem_var)
                                                if len(tem_var)!=0:
                                                    tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                    tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                    tem_Value_AND_Table.append(k)
                                                    # Table_name_for_value.append(k)
                                                # where_condition_var=
                                                break
                                            except:
                                                pass
                                        
                                        else:
                                            # print("4")
                                            try:
                                                tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                                # print("********",tem_var)
                                                if len(tem_var)!=0:
                                                    tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                    tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                    tem_Value_AND_Table.append(k)
                                                    # Table_name_for_value.append(k)
                                                # where_condition_var=
                                                break
                                            except:
                                                pass
                                    else:
                                        if tem_coloum_name[p]==seperated_By_Space_for_Value_search[i-2]:#share capital for (of any word like for present) 521 then true in this it check first "capital"
                                            
                                            if tem_coloum_name[p-1]==seperated_By_Space_for_Value_search[i-3]:# if "capital" present then "share" also check 
                                                # print("5")
                                                try:
                                                    tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                                    # print("********",tem_var)
                                                    if len(tem_var)!=0:
                                                        tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                        tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                        tem_Value_AND_Table.append(k)
                                                        # Table_name_for_value.append(k)
                                                    # where_condition_var=
                                                    break
                                                except:
                                                    pass
                                            else:
                                                # print("6")
                                                try:
                                                    tem_var=run_query(k,"SELECT "+Coloum_Name_AND_Table[j]+" FROM "+k+" WHERE "+Coloum_Name_AND_Table[j]+" = "+seperated_By_Space_for_Value_search[i])
                                                    # print("********",tem_var)
                                                    if len(tem_var)!=0:
                                                        tem_Value_AND_Table.append(Coloum_Name_AND_Table[j])#coloum
                                                        tem_Value_AND_Table.append(seperated_By_Space_for_Value_search[i])#Value
                                                        tem_Value_AND_Table.append(k)
                                                        # Table_name_for_value.append(k)
                                                    # where_condition_var=
                                                    break
                                                except:
                                                    pass
                            
                            # where_condition_var=" Where "+str(Coloum_Name_AND_Table[j])+" = "+seperated_By_Space_for_Value_search[i]
                        
                    break
        # if len(temp_value_NUMBER_with_table)!=0:
        #     # print("7")
        #     tem_Value_AND_Table.append(temp_value_NUMBER_with_table)
        # if len(tem_Value_AND_Table)!=0:  
        #         Table_name_for_value.append(k)
        #         Number_value_check_flag=False 
            # temp_value_NUMBER_with_table=[] 
        # Table_name_for_value.append(k)
                                
                                        
        Coloum_Name=[]

        
        # print("\n\n\n===================Coloum_Name_AND_Table",Coloum_Name_AND_Table)
        # print("\n\n\n///////////////////Keys_With_Tables",Keys_With_Tables)
      
        # if Flag_for_YearOnYearPercentageOf==True:
        #     tem_list=[]
        #     for i in range(len(seperated_By_Space_for_Value_search)):
        #         for j in range(len(Coloum_Name_AND_Table)):
        #             if seperated_By_Space_for_Value_search[i]==Coloum_Name_AND_Table[j]:
        #                 if len(seperated_By_Space_for_Value_search)-3>=i:
        #                     if seperated_By_Space_for_Value_search[i+1].isdigit():
        #                         tem_list.append(i)
        #                         tem_list.append(i+1)
        #                         if seperated_By_Space_for_Value_search[i+2]=='FOR':
        #                             tem_list.append(i+2)
        #     tem_list.sort(reverse=True)
        #     tem_str=""
        #     for i in range(len(tem_list)):
        #         tem_str=" "+tem_str+seperated_By_Space_for_Value_search[i]+" "
        #         seperated_By_Space_for_Value_search.pop(tem_list[i])
        #     tem_str_1=""
        #     for i in range(len(seperated_By_Space_for_Value_search)):
        #         tem_str_1=tem_str_1+seperated_By_Space_for_Value_search[i]+" "
        #     query=tem_str_1
        #     # print("///////////////////////////////////////////",query)
                
                            
            
      
      
      
      
      
      
      
    #   #===================================================================================================================================
    #     responsejoin=""
    #     # Check Text value present or Not In Table
    #     # quer2="SELECT * FROM "+"\""+k+"\""
    #     # All_data_of_Table=db.run(quer2)
    #     # All_data_of_Table=All_data_of_Table.split(",")
    #     # All_data_of_Table=str(All_data_of_Table).upper()
        
    #     # check_flag=False
    #     # for i in range(len(seperated_By_Space_for_Coloum_search)):
    #     #     if seperated_By_Space_for_Coloum_search[i].isdigit()!=True:
    #     #         if seperated_By_Space_for_Coloum_search[i] in All_data_of_Table:
    #     #             # db_chain = SQLDatabaseChain.from_llm(llm, db,use_query_checker=True,return_sql=True)# verbose=True,
    #     #             # responsejoin=db_chain(query)
    #     #             check_flag=True
    #     #             pass
    #     # if check_flag==True:
    #     # chain = create_sql_query_chain(AI21(temperature=0.1), db=SQLDatabase.from_uri(connection_url,include_tables=[k]))
    #     # responsejoin =chain.invoke({"question":query})
    #     # responsejoin =str(responsejoin).replace("'",'"')
    #     # query12="give Year on Year percentage of share capital for state bank of india of latest year whose type is s"
    #     responsejoin=get_only_Sql_Qury(k,query)
    #     responsejoin =str(responsejoin).replace("'",'"')
    #     # seperated_By_Space_for_Coloum_search_1=seperated_By_Space_for_Coloum_search
    #     # seperated_By_Space_for_Coloum_search_1[1]=temp_array_for_Key[1]
    #     # filtered_array = [item for item in seperated_By_Space_for_Coloum_search_1 if item != '']
    #     # result_string = ' '.join(filtered_array)
    #     # print("\n\n********************seperated_By_Space_for_Coloum_search_1",seperated_By_Space_for_Coloum_search_1)
    #     # print("\n\n********************k",k)
    #     # db = SQLDatabase.from_uri(connection_url,include_tables=[k],sample_rows_in_table_info=0)
    #     # db_chain = SQLDatabaseChain.from_llm(llm=AI21(temperature=0.5), db=SQLDatabase.from_uri(connection_url,include_tables=[k]),use_query_checker=True,return_sql=True)# verbose=True,
    #     # responsejoin=db_chain(query)
    #     # responsejoin =str(responsejoin['result']).replace("'",'"')

    #     print("\n\n---------------------query---->>>   ",query)
    #     print("\n\n---------------------responsejoin---->>>   ",responsejoin)
    #     tem_valueText = re.findall('(?<==)\W*"([^%"]*)"', responsejoin)
    #     tem_valueText=str(tem_valueText).upper().strip()
    #     tem_valueText=tem_valueText.replace("[","").replace("]","").replace("(","").replace(")","").replace("'","").split(",")

    #     #To remove space befor each word 

    #     for i in range(len(tem_valueText)):
    #         flg=False
    #         tem_var=tem_valueText[i].strip()
    #         valueText.append(tem_var)
    #         for j in range(len(seperated_By_Space_for_Value_search)):
    #             if tem_var==seperated_By_Space_for_Value_search[j]:
    #                 if len(seperated_By_Space_for_Value_search)-2>=j:
    #                     valueText.append(seperated_By_Space_for_Value_search[j+1])
    #                     flg=True
    #                     break
    #         if flg==False:
    #             valueText.append("-55565")
                
    #     print("\n\n===================valueText   ",valueText)

    #     if len(valueText[0])!=0:
    #         table_structure=db.get_table_info()
    #         table_structure=table_structure.replace("\t","").replace("\n","").split(",")
    #         coloum_name_of_textDatatype= re.findall(r'(\S+)\s+TEXT',str(table_structure))
    #         coloum_name_of_textDatatype=str(coloum_name_of_textDatatype).upper().replace("\'","").replace("[","").replace("]","").split(",")
    #         # print("\n\n===================coloum_name_of_textDatatype    ",coloum_name_of_textDatatype)
    #         #To remove space befor each word 
    #         for i in range(len(coloum_name_of_textDatatype)):
    #             coloum_name_of_textDatatype[i]=coloum_name_of_textDatatype[i].strip()
    #         for j in range(0,len(valueText),2):
    #             for i in range(len(coloum_name_of_textDatatype)):
    #                 try:
    #                     Temp_query_1="SELECT "+coloum_name_of_textDatatype[i]+" FROM "+k+" WHERE "+coloum_name_of_textDatatype[i]+" LIKE "+"\'"+valueText[j]+"%\'"    
    #                     tem_Text_value=db.run(Temp_query_1)
    #                     backup_ans=tem_Text_value
    #                     # print("========11111",Temp_query_1)
    #                     # print("=-===========",len(tem_Text_value))
    #                     backup_value=valueText[j]
    #                     if len(tem_Text_value[0])!=0:
    #                         # print("**********")
    #                         tem_var=valueText[j]
    #                         if len(valueText[j])!=1:
    #                             tem_var=valueText[j]+" "+valueText[j+1]
    #                         Temp_query_1="SELECT "+coloum_name_of_textDatatype[i]+" FROM "+k+" WHERE "+coloum_name_of_textDatatype[i]+" LIKE "+"\'"+tem_var+"%\'"    
    #                         tem_Text_value=db.run(Temp_query_1)
                            
    #                         valueText[j]=tem_var
    #                         # print("========22222",Temp_query_1)
    #                         # print("=-===========",len(tem_Text_value))
    #                         if len(tem_Text_value)==0:
    #                             # print("Originar value appened")
    #                             tem_Text_value=backup_ans
    #                             valueText[j]=backup_value

    #                 except:
    #                     pass
    #                 # print("\n\n//////////////\Temp_query_1",Temp_query_1)
    #                 tem_Text_value=tem_Text_value.replace(" (","").replace(",)","").replace("[","").replace("]","").replace("\'","")
    #                 tem_Text_value=tem_Text_value.replace("(","").split(",")
    #                 # print("\n\n//////////////tem_Text_value1",tem_Text_value)
    #                 # print("\n\n//////////////valueText",valueText[j])
    #                 # print("//////////////tem_Text_value2",tem_Text_value[0])
    #                 # print("//////////////tem_Text_value3",len(tem_Text_value))
    #                 to_check=tem_Text_value[0]
    #                 tem_Text_value=tem_Text_value[0].split()
    #                 valueText_1=valueText[j].split()
    #                 if len(to_check)!=0:
    #                     if len(valueText[j])==2:
    #                         if len(valueText[j])==len(to_check):
    #                             # print("1")
    #                             # print("\n\n===================tem_Text_value[0]    ",tem_Text_value[0])
    #                             tem_Value_AND_Table.append(coloum_name_of_textDatatype[i])
    #                             tem_Value_AND_Table.append(valueText[j])
    #                             tem_Value_AND_Table.append(k)
    #                             # Table_name_for_value.append(k)
    #                             # print("====== 66666",Temp_query_1)
    #                             # print("\n\n===================   Apeedned ")
    #                             # print("\n\n-=-=-=-=-=-=-=-=-=-=-==-=-tem_Value_AND_Table   ",tem_Value_AND_Table)
    #                             break
    #                         else:
    #                             pass
    #                     else:
    #                         try:
    #                             # print("2")
    #                             if valueText_1[0] in tem_Text_value:
    #                                 tem_Value_AND_Table.append(coloum_name_of_textDatatype[i])
    #                                 tem_Value_AND_Table.append(valueText[j])
    #                                 tem_Value_AND_Table.append(k)
    #                                 # Table_name_for_value.append(k)
    #                                 # print("====== 55555",Temp_query_1)
    #                                 # print("\n\n===================   Apeedned ")
    #                                 # print("\n\n-=-=-=-=-=-=-=-=-=-=-==-=-tem_Value_AND_Table   ",tem_Value_AND_Table)
    #                                 break
    #                         except:
    #                             pass
    #             # check_flag=False
                
    # # ==================================================================================================================================            
                
                
                
                
                
                
                
                
                
#  =====================================================================================================================================================               
        # it is use to store foren key in main key array
        keys3=[]
        keys3 = re.findall(r'(?<=FOREIGN KEY)\W*([^")]*)',db.get_table_info()) 
        keys3=str(keys3).replace("[","").replace("]","").replace("\'","")
        keys3=str(keys3).split(",")
        # print("//////////////////////keys3len",len(keys3[0]))
        # print("//////////////////////keys3",keys3)
        FOREIGN_key_of_table=[]
        if len(keys3[0])!=0:
            FOREIGN_key_of_table.append(k)
            for i in range(len(keys3)):
                FOREIGN_key_of_table.append(str(F_key_table[i]).strip())
                FOREIGN_key_of_table.append(str(keys3[i]).strip())
                
            FOREIGN_key_of_table.append(2)
            Keys_With_Tables.append(FOREIGN_key_of_table)
    # =====================================================================================================================================================            

    
    #je pan coloum value list madhe astil te coloum Table_name_for_coloum and Coloum_Name_AND_Table nasay la pahije
    # beacuse hya two coloum madhe Table_name_for_coloum and Coloum_Name_AND_Table value find karay che coloums aahet
    # print("\n\n----------------------Coloum_Name_AND_Table   Befor",Coloum_Name_AND_Table)
    # print("\n\n----------------------tem_Value_AND_Table",tem_Value_AND_Table)
    Coloum_Name_AND_Table=delete_value_from_coloumList(Coloum_Name_AND_Table,tem_Value_AND_Table)
    
    #then append onlt table name for futher use 
    # for i in range(0,len(Coloum_Name_AND_Table),3):
    #     Table_name_for_coloum.append(Coloum_Name_AND_Table[i])
    # print("\n\n----------------------Coloum_Name_AND_Table  ",Coloum_Name_AND_Table)
        
#  =====================================================================================================================================================       
        
    
    #To remove duplicate element
    Coloum_Name_AND_Table_1=Coloum_Name_AND_Table
    Coloum_Name_AND_Table=[]
    tem_length_For_Coloum_Identification=1
    for item in range(1,len(Coloum_Name_AND_Table_1),3):
        if Coloum_Name_AND_Table_1[item] not in Coloum_Name_AND_Table:
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[item-1])
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[item])
            Coloum_Name_AND_Table.append(tem_length_For_Coloum_Identification)
            tem_length_For_Coloum_Identification=tem_length_For_Coloum_Identification+1
            
            
 #  =====================================================================================================================================================           
            
            
            
            
    # print("\n\n*********************where_condition_var",where_condition_var)
    
    #To arrange Coloum name from this Coloum_Name_AND_Table according to question
    tem_array=[]
    tem_array_1=[]
    tem_similar_word_array=[]
    for j in range(len(seperated_By_Space_use)):
        for i in range(1,len(Coloum_Name_AND_Table),3):
            tem_var=str(Coloum_Name_AND_Table[i]).split("_")
            for k in range(len(tem_var)):
                    if seperated_By_Space_use[j]==tem_var[k]:
                        tem_array_1.append(Coloum_Name_AND_Table[i-1])#table
                        tem_array_1.append(seperated_By_Space_use[j])#value
                        tem_array_1.append(Coloum_Name_AND_Table[i+1])#number
                        # if seperated_By_Space_use[j+1]==tem_var[k+1]:
            
#  =====================================================================================================================================================            
            
            
            
            
            
            
            
# to find similar words like high, low
            for m in range(len(similar_words)):
                # print("\n\n+/////////////////////////////",similar_words)
                if seperated_By_Space_use[j]==similar_words[m]:
                    for l in range(len(tem_var)):
                        if seperated_By_Space_use[j+1]==tem_var[l]:
                            # print("11111111")
                            tem_similar_word_array.append(seperated_By_Space_use[j])
                            tem_similar_word_array.append(Coloum_Name_AND_Table[i])
                            tem_similar_word_array.append(Coloum_Name_AND_Table[i-1])
                            break
                        else:
                            if(len(seperated_By_Space_use)-2>j):
                                if seperated_By_Space_use[j+2]==tem_var[l]:
                                    # print("222222222")
                                    tem_similar_word_array.append(seperated_By_Space_use[j])
                                    tem_similar_word_array.append(Coloum_Name_AND_Table[i])
                                    tem_similar_word_array.append(Coloum_Name_AND_Table[i-1])
                                    break
    similar_word_array=remove_duplicate(tem_similar_word_array)
    tem_array=remove_duplicate(tem_array_1)
 #  =====================================================================================================================================================
    
    
    
    # print("\n\n++++++++++++++++++++++++Coloum_Name_AND_Table",similar_word_array)   
    # print("\n\n++++++++++++++++++++++++tem_array",tem_array)   
    tem_Coloum_Name_AND_Table=[]
    for j in range(tem_length_For_Coloum_Identification-1,0,-1):
        length=1
        tem_string_of_table=""
        tem_string_1=""
        # print("\n\ntem_length_For_Coloum_Identification-----",j)
        for i in range(len(tem_array)-1,0,-3):
            # print("\n\ntem_array-----",tem_array[i])
            if tem_array[i]==j:
                if length==1:
                    # print("1")
                    tem_string_of_table=tem_string_of_table+tem_array[i-2]
                    # print("***1",tem_string_of_table)
                    tem_string_1=tem_array[i-1]
                    # print("***5",tem_string_1)
                    length=-1
                else:
                    tem_string_1=tem_array[i-1]+"_"+tem_string_1
                    # print("***6",tem_string_1)
        if len(tem_string_1)!=0:
            tem_Coloum_Name_AND_Table.append(tem_string_1)    
            # print("*****3",tem_string_1)    
            tem_Coloum_Name_AND_Table.append(tem_string_of_table)   
            # print("*****4",tem_string_of_table)

    # print("\n\n----------------------tem_Value_AND_Table",tem_Value_AND_Table)
    # print("\n\n*********************Table_name_for_value",Table_name_for_value)
    # print("\n\n----------------------Coloum_Name_AND_Table",tem_Coloum_Name_AND_Table)
    # print("\n\n*********************Table_name_for_coloum",Table_name_for_coloum)
    # print("\n\n++++++++++++++++++++++++similar_word_array",similar_word_array) 
    
    Coloum_Name_AND_Table=[]
    for i in range(0,len(tem_Coloum_Name_AND_Table),2):#['company_master', 'COMPANY', 'balancesheet_backup', 'YEAR', 'balancesheet_backup', 'EQUITY_PAID_UP']
        flag=True
        for j in range(1,len(similar_word_array),3):#['HIGHEST', 'EQUITY_PAID_UP', 'balancesheet_backup', 'LATEST', 'YEAR', 'balancesheet_backup']
            if tem_Coloum_Name_AND_Table[i]==similar_word_array[j]:
                flag=False
                Coloum_Name_AND_Table.append(tem_Coloum_Name_AND_Table[i+1])#table
                Coloum_Name_AND_Table.append(tem_Coloum_Name_AND_Table[i])#Coloum Name
                Coloum_Name_AND_Table.append(similar_word_array[j-1])#Similar value
                break
            # else:
        if flag==True:
            Coloum_Name_AND_Table.append(tem_Coloum_Name_AND_Table[i+1])#table
            Coloum_Name_AND_Table.append(tem_Coloum_Name_AND_Table[i])#Coloum Name
            Coloum_Name_AND_Table.append('')#empty because similar word not present

    
    #just taking empty 3rd variable first example ['balancesheet_backup', 'INDUSTRY_CODE', 'HIGHEST', 'company_master', 'SHARE_CAPITAL', '']
    Coloum_Name_AND_Table_1=Coloum_Name_AND_Table
    # print("\n\n------------------------>>>  Coloum_Name_AND_Table :-  ",Coloum_Name_AND_Table_1)
    Coloum_Name_AND_Table=[]
    for i in range(2,len(Coloum_Name_AND_Table_1),3):
        if len(Coloum_Name_AND_Table_1[i])==0:
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i-2])
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i-1])
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i])
            
    for i in range(2,len(Coloum_Name_AND_Table_1),3):
        if len(Coloum_Name_AND_Table_1[i])!=0:
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i-2])
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i-1])
            Coloum_Name_AND_Table.append(Coloum_Name_AND_Table_1[i])

            
    
    # to remove same element from list example :- ['TYPE', 'S', 'balancesheet_backup', 'TYPE', 'S', 'balancesheet_backup', 'BSE_COMPANY_NAME', 'HDFCBANK', 'company_master']
    Value_AND_Table=remove_duplicate(tem_Value_AND_Table)
    
    
    

    try:#select keleli company cha code add karay la 
        # print("\n\n------------------------>>>  Value_AND_Table Befor:-  ",Value_AND_Table)
        # print("\n\n------------------------>>>  Coloum_Name_AND_Table Befor :-  ",Coloum_Name_AND_Table)
        tem_company=company.split()
        tem_flag=False
        flag_to_check_companyIsPresent_or_Not=True
        for i in range(1,len(Value_AND_Table),3):
        # print("============",tem_company)
            for j in range(len(tem_company)):
                tem_var=Value_AND_Table[i].split()
                if tem_company[j]==tem_var[0]:
                    primary_key=-1
                    for k in range(len(Keys_With_Tables)):
                        if Value_AND_Table[i+1]==Keys_With_Tables[k][0]:
                            primary_key=Keys_With_Tables[k][1]
                    Value_AND_Table[i-1]=primary_key
                    Value_AND_Table[i]=get_companyCode_of_select_company[-1]
                    tem_flag=True
                    flag_to_check_companyIsPresent_or_Not=False
                    break
            if tem_flag==True:
                break

        if flag_to_check_companyIsPresent_or_Not==True:

            # if tem_company[j] in seperated_By_Space:# beacuse select kelay ek and vichartoy dusra ch 
            Value_AND_Table.append('company_code')#coloum Name 
            Value_AND_Table.append(get_companyCode_of_select_company[-1])#value
            Value_AND_Table.append(get_companyCode_of_select_company[-2])#table
            
            
        for i in range(2,len(Value_AND_Table),3):
            Table_name_for_value.append(Value_AND_Table[i])
        for i in range(0,len(Coloum_Name_AND_Table),3):
            Table_name_for_coloum.append(Coloum_Name_AND_Table[i])
    except:
        query_answer="ERROR3..."
        error_function(query_answer,query)
    
    
                          
   #  =====================================================================================================================================================
    #to calculate latest year examle "give Latest share capital ?" means latest year
    if Flag_for_YearOnYearPercentageOf==False:
        try:
            for i in range(2,len(Coloum_Name_AND_Table),3):
                if Coloum_Name_AND_Table[i-2]=='balancesheet':
                    if Coloum_Name_AND_Table[i]=='LATEST':
                        # print("/***/////*/**/*///")
                        index=Value_AND_Table.index('company_code')
                        company_code=Value_AND_Table[index+1]
                        sql_query=Sql_query=f"select YEAR from {Coloum_Name_AND_Table[i-2]} where company_code ={company_code} order by YEAR desc limit 1"
                        year=run_query(Coloum_Name_AND_Table[i-2],sql_query)
                        Value_AND_Table.append('YEAR')#coloum
                        Value_AND_Table.append(year)#value
                        Value_AND_Table.append(Coloum_Name_AND_Table[i-2])#table
                        Coloum_Name_AND_Table[i]=""

        except:
            pass
        Coloum_Name_AND_Table_1=delete_value_from_coloumList(Coloum_Name_AND_Table,Value_AND_Table)    
        Coloum_Name_AND_Table=[]
        # print("\n\n----------------------4444444444444444-->>>  Coloum_Name_AND_Table_1 :-  ",Coloum_Name_AND_Table_1)
        Coloum_Name_AND_Table=Coloum_Name_AND_Table_1
    
    
    # print("\n\n------------------------>>>  Keys_With_Tables :-  ",Keys_With_Tables)
    
    
    #  =====================================================================================================================================================
    keys=[]
    
    merged_list = list(set(Table_name_for_coloum + Table_name_for_value))
    # use_vaeriable=remove_duplicate(use_vaeriable)
    # print("=-=-=-=-=---=-=-==========+++++++++++++",merged_list)


    for i in range(len(merged_list)):
        for j in range(len(Keys_With_Tables)):
            if merged_list[i]==Keys_With_Tables[j][0]:
                keys.append(Keys_With_Tables[j])

    Keys_With_Tables=[]
    # uppercased_list = [[element.upper() if isinstance(element, str) else element for element in inner_list] for inner_list in original_list]
    Keys_With_Tables=keys               
            
    
    
    
    #get f key properliy
    try:
        pop_index=-1
        insert_list=[]
        for i in range(len(Keys_With_Tables)):
            first_table=Table_name_for_value[0]
            second_table=Table_name_for_coloum[0]
            f_key=""
            if Keys_With_Tables[i][0]==first_table:
                if Keys_With_Tables[i][-1]==2:
                    tem_list= Keys_With_Tables[i]
                    pop_index=i
                    table_name=tem_list.pop(0)
                    num=tem_list.pop(-1)
                    for j in range(len(tem_list)):
                        if second_table==tem_list[j]:
                            f_key=tem_list[j+1]
                    insert_list.append(table_name)
                    insert_list.append(f_key)
                    insert_list.append(num)
        if pop_index!= -1:
            Keys_With_Tables.pop(pop_index)
            Keys_With_Tables.insert(pop_index,insert_list)
    except:
        pass
    
    print("\n\n------------------------>>>  Coloum_Name_AND_Table Befor:-  ",Coloum_Name_AND_Table)
    # if len(Table_name_for_coloum)
    tem_Table_name_for_coloum=Table_name_for_coloum
    # print("44",tem_Table_name_for_coloum)
    tem_list=[]
    for item in range(len(tem_Table_name_for_coloum)):
        if tem_Table_name_for_coloum[item] not in tem_list:
            tem_list.append(tem_Table_name_for_coloum[item])
    print("#####################tem_list  ",tem_list)
    tem_2_Coloum_Name_AND_Table=Coloum_Name_AND_Table
    tem_3_Coloum_Name_AND_Table=[]
    for i in range(len(tem_list)):
        tem_list_coloums=[]
        for j in range(0,len(tem_2_Coloum_Name_AND_Table),3):
            if tem_list[i]==tem_2_Coloum_Name_AND_Table[j]:
                tem_list_coloums.append(tem_2_Coloum_Name_AND_Table[j])
                tem_list_coloums.append(tem_2_Coloum_Name_AND_Table[j+1])
                tem_list_coloums.append(tem_2_Coloum_Name_AND_Table[j+2])
        tem_3_Coloum_Name_AND_Table.append(tem_list_coloums)

    print("#####################tem_3_Coloum_Name_AND_Table  ",tem_3_Coloum_Name_AND_Table)
    if len(tem_3_Coloum_Name_AND_Table)==0:
        tem_3_Coloum_Name_AND_Table.append("NULL")
                
            
    #to add only table name in list      
    print("\n\n=============================================================================================================\n\n")
    print("\n\n------------------------>>>  similar_word_array :-  ",similar_word_array) 
    print("\n\n------------------------>>>  Value_AND_Table After:-  ",Value_AND_Table)
    print("\n\n------------------------>>>  Table_name_for_value :-  ",Table_name_for_value)
    print("\n\n------------------------>>>  Coloum_Name_AND_Table :-  ",Coloum_Name_AND_Table)
    print("\n\n------------------------>>>  Table_name_for_coloum :-  ",Table_name_for_coloum)
    print("\n\n------------------------>>>  Keys_With_Tables :-  ",Keys_With_Tables)
    print("\n\n=============================================================================================================\n\n")
      
                    
                
                
    end_time_1 = time.time()
    elapsed_time = end_time_1 - start_time
    print(f"\n----------------->>>>>Execution time to get values: {elapsed_time} seconds")
    
    
    
    f_length=True
    The_Final_answar=""
    for i in range(len(tem_3_Coloum_Name_AND_Table)):
        The_Final_answar=The_Final_answar+str(query_answer)
        Coloum_Name_AND_Table=[]    
        Table_name_for_coloum=[]
        Coloum_Name_AND_Table=tem_3_Coloum_Name_AND_Table[i]    
        Table_name_for_coloum=tem_3_Coloum_Name_AND_Table[0]  
        print("####$$$$$$#############Coloum_Name_AND_Table   ",Coloum_Name_AND_Table)
                            
        # to 'Of' word before count, avg like 
        Of_word_flag=False
        add_of_arrary=['COUNT','AVG','SUM','AVERAGE']
        for i in range(1,len(Coloum_Name_AND_Table),3):
            if Coloum_Name_AND_Table[i+1] in add_of_arrary:
                Coloum_Name_AND_Table[i+1]=Coloum_Name_AND_Table[i+1]+' Of'
                Of_word_flag=True
            
        
        
        
        
        
    
            

        query_answer=""
        for_oneTable_operation_flag=True
        for_multipleTable_operation_flag=False
        try:
            #to check query is for one table or multiple table
            for a in range(len(Table_name_for_value)):
                for b in range(len(Table_name_for_coloum)):
                    if Table_name_for_value[a]!=Table_name_for_coloum[b]:
                        for_multipleTable_operation_flag=True
                        for_oneTable_operation_flag=False
            tem_var=Table_name_for_coloum[0]
            if for_oneTable_operation_flag==True:
                for i in range(len(Table_name_for_coloum)):
                    if tem_var!=Table_name_for_coloum[i]:
                        # if len(Table_name_for_value)==0:
                        for_oneTable_operation_flag=False
                        for_multipleTable_operation_flag=True
        except:
            # query_answer="I think Coloumn name is wrong..... Check Query"
            pass
            
        if (peers_group_flag or growth_flag or Flag_for_IndustryPeers or Flag_for_YearOnYearPercentageOf)==True:
            for_oneTable_operation_flag=False
            for_multipleTable_operation_flag=True
                
            
        print("\n\n\n")
        operation_flag=False
        # if give query has no value means this query for one table ex: give all md

        if for_oneTable_operation_flag==True:
            # query=query+" For "+get_companyCode_of_select_company[-1]
            
            print("\n=================================== For One Table   ===============================================================\n\n")
            
            query="give "
            for i in range(1,len(Coloum_Name_AND_Table),3):
                query=query+Coloum_Name_AND_Table[i+1]+" "+Coloum_Name_AND_Table[i]+" , "
            if Of_word_flag !=True:
                query=query+" For "+get_companyCode_of_select_company[-2]+" Is "+get_companyCode_of_select_company[-1]
            print("\n==========>>>> query",query)  
            if operation_flag==False:
                if len(Value_AND_Table)==0:
                    table=""
                    for i in range(len(Coloum_Name_AND_Table)):
                        # print("****",len(Coloum_Name_AND_Table[i]))
                        if len(Coloum_Name_AND_Table[i])!=0:
                            # print("****",Coloum_Name_AND_Table[i][0])
                            table=Coloum_Name_AND_Table[0]
                            answer=get_query_ans(table,query)
                            query_answer=get_proper_answar(answer,Coloum_Name_AND_Table)
                            print("\nFirst Operation")
                            operation_flag=True
                            break
            
            # if value and coloum name present in one table then ex:- give all share capital for type s
            flg=False
            # query= "Give isin for 100410"
            if operation_flag==False:
                for i in range(len(Table_name_for_value)):
                    for j in range(len(Table_name_for_coloum)):
                        if Table_name_for_value[i]== Table_name_for_coloum[j]:
                            flg=True
                        else:
                            flg=False
                    if flg==True:
                        table=Table_name_for_value[i]
                        answer=get_query_ans(table,query)
                        query_answer=get_proper_answar(answer,Coloum_Name_AND_Table)
                        operation_flag=True
                        print("\nsecond Operation")
                        break
            
        
        if for_multipleTable_operation_flag==True:
            print("\n=================================== For Multiple Table ===============================================================\n\n")
            if operation_flag==False:
                    # print("****1")
                    P_key=""
                    First_table=""
                    where_condition=""
                    First_value_take_from_table=" For "
                    Second_value_take_from_table=" "
                    first_similar_condition=" For "
                    first_flag=True
                    second_flag=True
                    if len(Table_name_for_value)!=0:#(which company has highest equity paid up in latest year) hya qution mule ha use kela aahe 
                        # print("****2")
                        for a in range(2,len(Value_AND_Table),3):
                            for b in range(0,len(Coloum_Name_AND_Table),3):
                                if Value_AND_Table[a]!=Coloum_Name_AND_Table[b]:
                                    if first_flag == True:
                                        # print("1 1")
                                        First_table=Value_AND_Table[a]
                                        First_value_take_from_table=First_value_take_from_table+Value_AND_Table[a-2]+" IS "+Value_AND_Table[a-1]+" "
                                        first_flag=False
                                        break
                                    else:
                                        # print("1 2")
                                        First_table=Value_AND_Table[a]
                                        First_value_take_from_table=First_value_take_from_table+" And "+Value_AND_Table[a-2]+" IS "+Value_AND_Table[a-1]+" "
                                        break
                                else:
                                    if Value_AND_Table[a]==Coloum_Name_AND_Table[b]:
                                        if second_flag == True:
                                            # print("2 1")
                                            Second_value_take_from_table=Second_value_take_from_table+Value_AND_Table[a-2]+" IS "+Value_AND_Table[a-1]+" "
                                            second_flag=False
                                            break
                                        else:
                                            # print("2 2")
                                            Second_value_take_from_table=Second_value_take_from_table+" And "+Value_AND_Table[a-2]+" IS "+Value_AND_Table[a-1]+" "     
                                            break
                        tem_len=0
                        
                        # print("================First_value_take_from_table",First_value_take_from_table)
                        # print("================Second_value_take_from_table",Second_value_take_from_table)
                        #for similar condition
                        for i in range(0,len(Coloum_Name_AND_Table),3):
                            if First_table==Coloum_Name_AND_Table[i]:
                                if tem_len==0:
                                    first_similar_condition=first_similar_condition+Coloum_Name_AND_Table[i+2]+" "+Coloum_Name_AND_Table[i+1]+" "
                                    tem_len=tem_len+2
                                else:
                                    first_similar_condition=first_similar_condition+" And "+Coloum_Name_AND_Table[i+2]+" "+Coloum_Name_AND_Table[i+1]+" "
                                
                                    # print("**************",Second_where_condition)
                        # print("================Second_value_take_from_table",first_similar_condition)
                        # print("--------+++++++1")
                        First_query_answer=""

                        Final_key=""
                        
                        for i in range(len(Keys_With_Tables)):
                            if Keys_With_Tables[i][-1]==2:
                                F_key=Keys_With_Tables[i][1]
                                if First_table==Keys_With_Tables[i][0]:
                                    Final_key=Keys_With_Tables[i][1] 
                                    break
                                
                        for i in range(len(Keys_With_Tables)):
                            F_key=""
                            P_key=""
                            # print("------")
                            # print("**",First_table)
                            # print("**",Keys_With_Tables[i][0])
                            # print("------")
                            # if First_table==Keys_With_Tables[i][0]:
                                # print("--------+++++++2")
                            if Keys_With_Tables[i][-1]==2:
                                F_key=Keys_With_Tables[i][1]
                            if Keys_With_Tables[i][-1]==1:
                                P_key=Keys_With_Tables[i][1]
                            # print("**************F_key",F_key)
                            # print("**************P_key",P_key)
                            # print("4")
                            if Flag_for_IndustryPeers==False:
                                # print("1")
                                # print("second_table====",Coloum_Name_AND_Table[0])
                                # print("Keys_With_Tables[i][0]====",Keys_With_Tables[i][0])
                                second_table=Coloum_Name_AND_Table[0]
                                if second_table==Keys_With_Tables[i][0]:
                                    # print("2")
                                    P_key=Keys_With_Tables[i][1]
                                    if (F_key not in Value_AND_Table) and (P_key not in Value_AND_Table)  :
                                        # First_table=Keys_With_Tables[i][0]
                                        # First_value_take_from_table=Value_AND_Table[0][1]
                                        if len(first_similar_condition)!=5:
                                            First_query="What is "+Final_key+First_value_take_from_table+first_similar_condition
                                        else:
                                            First_query="What is "+Final_key+First_value_take_from_table
                                        
                                        # where_condition_var
                                        # print("\n\n==============================First_value_take_from_table",First_value_take_from_table)
                                        print("\n\n==============================First_query  =====>>>>>>>",First_query)

                                        First_query_answer=get_query_ans(First_table,First_query)
                                        # First_query_answer=str(First_query_answer).replace(",","")
                                        # print("\n\n==============================First_query",First_query_answer)
                                    else:
                                        # print("=====")
                                        try:
                                            position_of_pKeyOrFkey=Value_AND_Table.index(P_key)
                                            First_query_answer=Value_AND_Table[position_of_pKeyOrFkey+1]
                                        except:
                                            try:
                                                position_of_pKeyOrFkey=Value_AND_Table.index(F_key)
                                            except:
                                                pass
                                            First_query_answer=Value_AND_Table[position_of_pKeyOrFkey+1]
                                        
                                else:
                                    continue        
                                    
                                
                                
                                
                            
                            if Flag_for_YearOnYearPercentageOf==True:
                                
                                First_query_answer=str(First_query_answer).replace(",","")
                                # print("\n\n\nIn Flag_for_YearOnYearPercentageOf\n\n")
                                                    # print("================First_value_take_from_table",First_value_take_from_table)
                                Second_value_take_from_table=""
                                second_flag=True
                                year=0
                                year_coloum_name=""
                                for a in range(2,len(Value_AND_Table),3):
                                    # print("1")
                                    for b in range(0,len(Coloum_Name_AND_Table),3):
                                        # print("2")
                                        if Value_AND_Table[a]==Coloum_Name_AND_Table[b]:
                                            if second_flag == True:
                                                # print("***/-/-/-/-/",str(Value_AND_Table[a-1]).isdigit())
                                                if str(Value_AND_Table[a-1]).isdigit()==True:
                                                    year=Value_AND_Table[a-1]
                                                    year_coloum_name=Value_AND_Table[a-2]
                                                    break
                                                else:
                                                    Second_value_take_from_table=" "+Second_value_take_from_table+Value_AND_Table[a-2]+" = \'"+Value_AND_Table[a-1]+"\' "
                                                    second_flag=False
                                                    break
                                
                                
                                # print("\n\n================Second_value_take_from_table    ",Second_value_take_from_table)

                                Main_Thing_to_find=""
                                second_Table=""
                                ANS_current_year=0
                                ANS_previous_year=0
                                for b in range(1,len(Coloum_Name_AND_Table),3):
                                    if Coloum_Name_AND_Table[b+1]!=('LATEST' or 'CURRENT'):
                                        Main_Thing_to_find=Coloum_Name_AND_Table[b]
                                        second_Table=Coloum_Name_AND_Table[b-1]
                                    else:
                                        if Coloum_Name_AND_Table[b+1]==('LATEST' or 'CURRENT'):
                                            year_coloum_name=Coloum_Name_AND_Table[b]
                                try:
                                    if year == 0:
                                        # latest_year_Sql_query=f"SELECT MAX({year_coloum_name}) FROM {second_Table} WHERE {P_key} = {First_query_answer}"
                                        latest_year_Sql_query=f"select {year_coloum_name} from {second_Table} where {P_key} = {First_query_answer} order by {year_coloum_name} desc limit 2"
                                        two_year=run_query(second_Table,latest_year_Sql_query)
                                        two_year=two_year.split()
                                        current_year=two_year[0]
                                        previous_year=two_year[1]
                                    else:
                                        Sql_query=f"select {year_coloum_name} from {second_Table} where {P_key} = {First_query_answer} and {year_coloum_name}<={year} order by {year_coloum_name} desc limit 2"
                                        two_year=run_query(second_Table,Sql_query)
                                        # print("************",Sql_query)
                                        # print("************",two_year)
                                        two_year=two_year.split()
                                        current_year=two_year[0]
                                        previous_year=two_year[1]
                                        # coloum_name_of_year=year_coloum_name
                                    # print("\n\n================current_year   ",current_year)
                                    # print("\n\n================previous_year   ",previous_year)
                                
                                    # SQL_current_year=f"SELECT {Main_Thing_to_find} FROM {second_Table} WHERE {P_key} = {First_query_answer} And {coloum_name_of_year} = {current_year} And {Second_value_take_from_table}" 
                                    SQL_current_year=f"SELECT {Main_Thing_to_find} FROM {second_Table} WHERE {P_key} = {First_query_answer} And {year_coloum_name} = {current_year}" 
                                    print("\n--------------SQL_current_year    ",SQL_current_year)
                                    ANS_current_year=float(run_query(second_Table,SQL_current_year))
                                    print("\n>>>>>>>>>>>>>>>SQL_current_year _Answar   ",ANS_current_year)
                                    # SQL_previous_year=f"SELECT {Main_Thing_to_find} FROM {second_Table} WHERE {P_key} = {First_query_answer} And {coloum_name_of_year} = {previous_year} And {Second_value_take_from_table}" 
                                    SQL_previous_year=f"SELECT {Main_Thing_to_find} FROM {second_Table} WHERE {P_key} = {First_query_answer} And {year_coloum_name} = {previous_year}" 
                                    print("\n--------------SQL_previous_year    ",SQL_previous_year)
                                    ANS_previous_year=float(run_query(second_Table,SQL_previous_year))
                                    print("\n>>>>>>>>>>>>>>>ANS_previous_year _Answar   ",ANS_previous_year)
                                        
                                        
                                        
                                        
                                    # print("\n\n***********ANS_current_year  ",ANS_current_year)
                                    # print("\n\n***********ANS_previous_year  ",ANS_previous_year)
                                    query_answer=(float(ANS_current_year) - float(ANS_previous_year))/float(ANS_previous_year)*100
                                    query_answer = "{:.3f}%".format(query_answer)
                                    ans="The Year on Year percentage is "+query_answer
                                    if growth_flag==True:
                                        ans=""
                                        ans="The growth is "+query_answer
                                    query_answer=ans
                                    print("\n\n-=-=-=-=-=-=-=-=-=-=-",query_answer)
                                    break
                                except:
                                    query_answer="ERROR5...."
                            
                            elif Flag_for_IndustryPeers==True:
                                #for "Who are industry peers"
                                SQL_Query_1=f"Select industry_code from company_master where company_code={Value_AND_Table[1]}"       
                                # SQL_Query_1=f'Give industry code whose company code is {Value_AND_Table[1]}'       
                                # second_query_answer=get_query_ans('company_master',SQL_Query_1)
                                second_query_answer=db.run(SQL_Query_1)
                                ind_code=second_query_answer
                                print("\n============>>>>>>>>>>>>>>>>>SQL_Query_1    ",SQL_Query_1)
                                print("\n============>>>>>>>>>>>>>>>>>ind_code    ",ind_code)
                                industry_code=run_query('company_master',SQL_Query_1)
                                # print("===========ind_code ",ind_code)
                                SQL_query_2=f"select company from company_master where industry_code={industry_code} limit 5"
                                # SQL_query_2=f"Give 5 company whose industry code is {ind_code}"
                                
                                if AllWord_index!=-1:
                                    SQL_query_2=""
                                    # SQL_query_2=f"Give company whose industry code is {ind_code}"
                                    SQL_query_2=f"select company from company_master where industry_code={industry_code}"
                                if countWord_index!=-1:
                                    SQL_query_2=""
                                    # SQL_query_2=f"Give count of company whose industry code is {ind_code}"
                                    SQL_query_2=f"select count(company) from company_master where industry_code={industry_code}"
                                all_companys=db.run(SQL_query_2)
                                print("\n============>>>>>>>>>>>>>>>>>SQL_Query_2    ",SQL_query_2)
                                print("\n============>>>>>>>>>>>>>>>>>all_companys    ",all_companys)
                                # all_companys=get_query_ans('company_master',SQL_query_2)
                                all_companys=str(all_companys).replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",").replace("\'","")
                                all_companys=all_companys.split(",")
                                if len(all_companys[-1])==0:
                                    all_companys.pop(-1)
                                # print("===========",all_companys)
                                if countWord_index!=-1:
                                    all_companys=str(all_companys).replace(",","").replace("\'","").replace("[","").replace("]","")
                                    all_companys=f"The count of industry peers is {all_companys}"
                                    query_answer=all_companys
                                elif AllWord_index!=-1:
                                    query_answer=all_companys
                                else:
                                    tem_var="These are few"
                                    first_time=False
                                    all_companys[-1]="and "+all_companys[-1]+" etc.."
                                    for i in range(len(all_companys)):
                                        if first_time==False:
                                            tem_var=tem_var+f" industry peers companys are {all_companys[i]}"
                                            first_time=True
                                        else:
                                            tem_var=tem_var+" , "+all_companys[i]
                                    query_answer=tem_var
                                    
                                break
                            elif Flag_for_housePeers==True:
                                #for "Who are industry peers"
                                SQL_Query_1=f"Select house_code from company_master where company_code={Value_AND_Table[1]}"       
                                # SQL_Query_1=f'Give industry code whose company code is {Value_AND_Table[1]}'       
                                # second_query_answer=get_query_ans('company_master',SQL_Query_1)
                                second_query_answer=db.run(SQL_Query_1)
                                ind_code=second_query_answer
                                print("\n============>>>>>>>>>>>>>>>>>SQL_Query_1    ",SQL_Query_1)
                                print("\n============>>>>>>>>>>>>>>>>>ind_code    ",ind_code)
                                house_code=run_query('company_master',SQL_Query_1)
                                # print("===========ind_code ",ind_code)
                                SQL_query_2=f"select company from company_master where house_code={house_code} limit 5"
                                # SQL_query_2=f"Give 5 company whose industry code is {ind_code}"
                                
                                if AllWord_index!=-1:
                                    SQL_query_2=""
                                    # SQL_query_2=f"Give company whose industry code is {ind_code}"
                                    SQL_query_2=f"select company from company_master where house_code={house_code}"
                                if countWord_index!=-1:
                                    SQL_query_2=""
                                    # SQL_query_2=f"Give count of company whose industry code is {ind_code}"
                                    SQL_query_2=f"select count(company) from company_master where house_code={house_code}"
                                all_companys=db.run(SQL_query_2)
                                print("\n============>>>>>>>>>>>>>>>>>SQL_Query_2    ",SQL_query_2)
                                print("\n============>>>>>>>>>>>>>>>>>all_companys    ",all_companys)
                                # all_companys=get_query_ans('company_master',SQL_query_2)
                                all_companys=str(all_companys).replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",").replace("\'","")
                                all_companys=all_companys.split(",")
                                if len(all_companys[-1])==0:
                                    all_companys.pop(-1)
                                # print("===========",all_companys)
                                if countWord_index!=-1:
                                    all_companys=str(all_companys).replace(",","").replace("\'","").replace("[","").replace("]","")
                                    all_companys=f"The count of house peers is {all_companys}"
                                    query_answer=all_companys
                                elif AllWord_index!=-1:
                                    query_answer=all_companys
                                else:
                                    tem_var="These are few"
                                    first_time=False
                                    all_companys[-1]="and "+all_companys[-1]+" etc.."
                                    for i in range(len(all_companys)):
                                        if first_time==False:
                                            tem_var=tem_var+f" house peers companys are {all_companys[i]}"
                                            first_time=True
                                        else:
                                            tem_var=tem_var+" , "+all_companys[i]
                                    query_answer=tem_var
                                    
                                break
                            
                            
                            
                            
                            
                            
                            #(===================== Second query=================)
                            else:                            
                                if 'COUNT' in Coloum_Name_AND_Table[2]:
                                    if len(Coloum_Name_AND_Table)==3:
                                        SQLQuery=f"SELECT COUNT({Coloum_Name_AND_Table[1]}) FROM {Coloum_Name_AND_Table[0]} WHERE {Value_AND_Table[0]} = {Value_AND_Table[1]}"
                                        second_query_answer=db.run(SQLQuery)
                                        print("\n\n=========================Second_query  =====>>>>>>>",SQLQuery)
                                        if len(second_query_answer)!=0:
                                            query_answer=get_proper_answar(second_query_answer,Coloum_Name_AND_Table)
                                        else:
                                            query_answer="ERROR6...."
                                        
                                else:
                                    Temp_query="Give  for "+P_key+" "+First_query_answer
                                    Temp_query=str(Temp_query).split(" ")
                                    temp_string=" "
                                    # second_similar_condition=" "
                                    second_table=Coloum_Name_AND_Table[0]
                                    tem_len=True
                                    for b in range(1,len(Coloum_Name_AND_Table),3):
                                        flg=True
                                        for c in range(len(Temp_query)):
                                            if Coloum_Name_AND_Table[b]==Temp_query[c]:
                                                flg=False
                                        if flg==True:
                                            if second_table==Coloum_Name_AND_Table[b-1]:
                                                if tem_len==True:
                                                    temp_string=temp_string+str(Coloum_Name_AND_Table[b+1])+" " +str(Coloum_Name_AND_Table[b])
                                                    tem_len=False
                                                else:
                                                    if tem_len==False:
                                                        temp_string=temp_string+" And "+str(Coloum_Name_AND_Table[b+1])+" " +str(Coloum_Name_AND_Table[b])
                                            # temp_string=temp_string+second_similar_condition

                                    # print("\n\n=====================Second_value_take_from_table    ",Second_value_take_from_table)
                                    # print("\n\n=====================Second_value_take_from_table    ",len(Second_value_take_from_table))
                                    # print("\n\n=====================temp_string    ",temp_string)
                                    if len(Second_value_take_from_table)==1:        
                                        Second_query="Give"+temp_string+" for "+P_key+" Is "+First_query_answer
                                    else:    
                                        Second_query="Give"+temp_string+" for "+P_key+" Is "+First_query_answer+" And "+Second_value_take_from_table
                                    # Second_query="Give  EQUITY PAID UP And LATEST YEAR for company_code Is 100209"
                                        # Second_query="Give "+Coloum_Name_AND_Table[1]+" for "+P_key+" "+First_query_answer+where_condition_var
                                    print("\n\n=========================Second_query  =====>>>>>>>",Second_query)
                                    second_query_answer=get_query_ans(second_table,Second_query)
                                    # print("\n\n=========================second_query_answer  =====>>>>>>>",second_query_answer)
                                    if len(second_query_answer)!=0:
                                        query_answer=get_proper_answar(second_query_answer,Coloum_Name_AND_Table)
                                    else:
                                        query_answer="ERROR6...."
                                    
                                    
                                
                                #===================================================
                                # For this question what is peers group of this sector
                                
                                if len(Coloum_Name_AND_Table)==3:
                                    if peers_group_flag==True:
                                        second_query_answer=second_query_answer.replace("\'","").replace(",","")
                                        SQL_query=f"SELECT COMPANY FROM {First_table} where {Final_key} in ( SELECT {Final_key} FROM {second_table} WHERE {temp_string} LIKE \'%{second_query_answer}%\') LIMIT 5"
                                        if AllWord_index!=-1:
                                            SQL_query=f"SELECT COMPANY FROM {First_table} where {Final_key} in ( SELECT {Final_key} FROM {second_table} WHERE {temp_string} LIKE \'%{second_query_answer}%\')" 
                                        if countWord_index!=-1:
                                            SQL_query=f"SELECT count(*) FROM {First_table} where {Final_key} in ( SELECT {Final_key} FROM {second_table} WHERE {temp_string} LIKE \'%{second_query_answer}%\')"  
                                        industry=db.run(SQL_query)
                                        industry=industry.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",").replace("\'","")
                                        # print("\n\n=================industry2222",industry)
                                        industry=industry.split(",")
                                        if len(industry[-1])==0:
                                            industry.pop(-1)
                                        print("\n\n=================SQL_query",SQL_query)
                                        print("\n\n=================industry",industry)
                                        query_answer=""
                                        if AllWord_index!=-1:
                                            # print("1")
                                            query_answer=industry
                                        elif countWord_index!=-1:
                                            # print("2")
                                            industry=str(industry).replace("[","").replace("]","").replace("\'","")
                                            tem_var=f"The Count of peer groups For {second_query_answer} sector is {industry}"
                                            query_answer=tem_var
                                        else: 
                                            tem_var="These are few"
                                            first_time=False
                                            industry[-1]="and "+industry[-1]+" etc.."
                                            for i in range(len(industry)):
                                                if first_time==False:
                                                    tem_var=tem_var+f" peer groups For {second_query_answer} sector are {industry[i]}"
                                                    first_time=True
                                                else:
                                                    tem_var=tem_var+" , "+industry[i]
                                            query_answer=tem_var
                                            # print("3")
                                            

                                operation_flag=True
                                print("\nthird Operation")
                                
                                
                                
                                break
                            
                                
                                    
                    else: #give company who has highest equity paid up
                        grouped = {}
                        first_similar_condition=[]
                        
                        for s in range(0,len(Coloum_Name_AND_Table),3):
                            prefix = Coloum_Name_AND_Table[s]
                            if prefix not in grouped:
                                grouped[prefix] = []
                            grouped[prefix].append(Coloum_Name_AND_Table[s])
                            grouped[prefix].append(Coloum_Name_AND_Table[s+1])
                            grouped[prefix].append(Coloum_Name_AND_Table[s+2])
                        
                        tem_Coloum_Name_AND_Table = list(grouped.values())
                        # print("-==-=-=-=-=-=-=-=-=-=-=-=-=",tem_Coloum_Name_AND_Table)
                        
                        First_table=tem_Coloum_Name_AND_Table[1][0]
                        second_table=tem_Coloum_Name_AND_Table[0][0]
                        for j in range(len(tem_Coloum_Name_AND_Table)):
                            tem_string=""
                            tem_len=0
                            for i in range(0,len(tem_Coloum_Name_AND_Table[j]),3):
                                # if First_table==tem_Coloum_Name_AND_Table[j][i]:
                                if tem_len==0:
                                    tem_string=tem_string+tem_Coloum_Name_AND_Table[j][i+2]+" "+tem_Coloum_Name_AND_Table[j][i+1]+" "
                                    tem_len=tem_len+2
                                else:
                                    tem_string=tem_string+" For "+tem_Coloum_Name_AND_Table[j][i+2]+" "+tem_Coloum_Name_AND_Table[j][i+1]+" "
                            first_similar_condition.append(tem_string)
                        # print("-==-=-=-=-=-=-=-=-=-=-=-=-=",first_similar_condition)
                        for i in range(len(Keys_With_Tables)):
                            # print("***",Keys_With_Tables[i][0])
                            if First_table==Keys_With_Tables[i][0]:
                                if Keys_With_Tables[i][-1]==2:
                                    f_key=Keys_With_Tables[i][1]
                                    first_query=" Give "+f_key+" For "+first_similar_condition[-1]
                                    print("\n\n==============================First_query",first_query)
                                    First_query_answer=get_query_ans(First_table,first_query)
                                    First_query_answer=str(First_query_answer).replace(",","")
                                    Second_query=" Give "+first_similar_condition[-2]+" For "+First_query_answer
                                    print("\n\n==============================Second_query",Second_query)
                                    
                                    second_query_answer=get_query_ans(second_table,Second_query)
                                    query_answer=second_query_answer
                                    operation_flag=True
                                    print("\nforth Operation")
                                    break
        if f_length==True:
            The_Final_answar=The_Final_answar+str(query_answer)+" " 
            query_answer=""    
            f_length=False    
        else:
            The_Final_answar=The_Final_answar+"And "+str(query_answer)+" " 
            query_answer=""                             
                                    
                                
                    
                    
                                
        
    if len(query_answer)==0:
        query_answer="ERROR7...."
        # query_answer=get_query_ans(table,query)
    questions_dbt.append(query1)                
    # query_answer=get_query_ans(str(table).replace("[","").replace("]","").replace("'",""),query)
    answers_dbt.append(The_Final_answar)
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"\n\n----------------->>>>>Execution time: {elapsed_time} seconds\n")

    return JsonResponse({"questions":questions_dbt,"answers":answers_dbt})                 
    # return render(request,'Client.html',{"questions":questions,"answers":answers,"filename":filename})


#je pan coloum value list madhe astil te coloum Table_name_for_coloum and Coloum_Name_AND_Table nasay la pahije
# beacuse hya two coloum madhe Table_name_for_coloum and Coloum_Name_AND_Table value find karay che coloums aahet
def delete_value_from_coloumList(Coloum_Name_AND_Table,tem_Value_AND_Table):
    tem_for_To_store_Position=[]
    for j in range(1,len(Coloum_Name_AND_Table),3):
        for i in range(0,len(tem_Value_AND_Table),3):
            if tem_Value_AND_Table[i]==Coloum_Name_AND_Table[j]:
                tem_for_To_store_Position.append(j+1)
                tem_for_To_store_Position.append(j)
                tem_for_To_store_Position.append(j-1)
                break
         
    # To delete that position which was store in previous
    tem_for_To_store_Position.sort(reverse=True)
    # print("\n\n**************tem_for_To_store_Position",tem_for_To_store_Position) 
    for i in tem_for_To_store_Position:
        Coloum_Name_AND_Table.pop(i)
    return Coloum_Name_AND_Table






def get_proper_answar(ans,Coloum_Name_AND_Table):
    try:
        # print("==============",ans)
        # ans=ans.replace("\'","").replace(",","")
        ans=ans.split(",")
        if len(ans)<5:
            tem_str="The "
            length=0
            flag=False
            first_time=True
            commom_word=['SUM','AVG','AVERAGE']
            for j in range(1,len(Coloum_Name_AND_Table),3):
                tem=Coloum_Name_AND_Table[j].replace("_"," ")
                if Coloum_Name_AND_Table[j+1] in commom_word :
                    Coloum_Name_AND_Table[j+1]=Coloum_Name_AND_Table[j+1]+' of '
                else:
                    if len(Coloum_Name_AND_Table[j+1])!=0:
                        tem_str=tem_str+Coloum_Name_AND_Table[j+1]+" "
                        Coloum_Name_AND_Table[j+1]=''
                    
            for j in range(1,len(Coloum_Name_AND_Table),3):
                tem=Coloum_Name_AND_Table[j].replace("_"," ")
                for k in range(len(ans)):
                    try:
                        if first_time ==True:
                            tem_str=tem_str+Coloum_Name_AND_Table[j+1]+" "+tem+" is "+str(ans[k+length]).replace("\'","").replace("[","").replace("]","").replace("(","").replace(")","")
                            length=length+1
                            first_time=False
                            # print("-=-==-=-=-=-=-=-=-=-=-==-=-=-=-=-=-        1",tem_str)
                            break
                        else:
                            tem_str=tem_str+" and "+Coloum_Name_AND_Table[j+1]+" "+tem+" is "+str(ans[k+length]).replace("\'","").replace("[","").replace("]","").replace("(","").replace(")","")
                            length=length+1
                            first_time=False
                            # print("-=-==-=-=-=-=-=-=-=-=-==-=-=-=-=-=-    2",tem_str)
                            break
                    except:
                        flag=True
                        break
                if flag==True:
                    break
            tem_str=tem_str.lower()
            tem_str = tem_str.split()
            


        # Capitalize the first letter of the first word
            if tem_str:
                tem_str[0] = tem_str[0].capitalize()

        # Join the words back into a single string
            formatted_string = ' '.join(tem_str)
            # print("=========================",formatted_string)
        else:
            formatted_string=ans
    except:
        formatted_string="ERROR8..."
    

    return formatted_string

    




def get_query_ans(table,query):
    # print("table******",table)
    # print("table******",query)
    
    # db = SQLDatabase.from_uri(connection_url,include_tables=['COMPANY_MASTER','HOUSE_MST','Balancesheet'],sample_rows_in_table_info=5)
    db = SQLDatabase.from_uri(connection_url,include_tables=[table],sample_rows_in_table_info=0)
    # db = SQLDatabase.from_uri("sqlite:///trainee_database.db",include_tables=['Company_Master','sheet'])#,'Company_Master','Balancesheet_backup'
    llm = AI21(temperature=0)
    # query=request.POST.get('question') 
    # print("\n\n-------------------------",db.get_table_info())
    table_structure=db.get_table_info()
    table_structure=table_structure.replace("\t","").replace("\n","").split(",")
    coloum_name_of_textDatatype= re.findall(r'(\S+)\s+TEXT',str(table_structure))

    
    



    seperatedBySpace_query=str(query).upper().split(" ")
    # print("\n\n\n-----------------")
    # print(str(query).upper())
    # print(type(query))
    # print("-----------------\n\n\n")
    
    #To get Number from Question For accurecy purpose 
    conditionFor_AllWord_Flag=False
    number_length=0
    positionOFThatNumber=[]
    for i in range(len(seperatedBySpace_query)):
        if seperatedBySpace_query[i]==('AND'):
            conditionFor_AllWord_Flag=True
        if seperatedBySpace_query[i].isdigit():
            number_length=number_length+1
            positionOFThatNumber.append(i)

    db_chain = SQLDatabaseChain.from_llm(llm, db,use_query_checker=True,return_sql=True)# verbose=True,
    response=db_chain(query)
    
    
    # print("\n\n***********--*-----++++++++response",response)
    response=str(response['result']).upper()
    # response_1=response.split()
    # response_1[-1]=response_1[-1].replace(";","")
    # if 'LIMIT' in response_1:
    #     select_index = response_1.index('SELECT')
    #     select_limit = response_1.index('LIMIT')
    #     after_limit_value=response_1[select_limit+1]
    #     response_1[select_index] = 'SELECT TOP '+after_limit_value
    #     response_1.pop(select_limit+1)
    #     response_1.remove('LIMIT')
        
    #     response=''
    #     response=' '.join(response_1)
    print("\n\n\nBefor Poressing Query------------------->>>>>>>>>   ",response)
        

    
    
    #seperate text by double couts ""
    response=response.replace("\"","\'")
    response=response.replace(";","")
    if conditionFor_AllWord_Flag==True:
        response=response.replace("INTERSECT","UNION")
    
    separateByCout = re.findall(r'\'(.+?)\'',response) 
    #Get the database table names 

    splitBySpace=response.split(" ")
    #Convert the  Text in Upper case and Add LIKE operator
    
    # for i in range(len(separateByCout)):
    #     if i in matches:
    #         pass
    #     else:
    #         if isinstance(separateByCout[i], str):
    #             print("\n",separateByCout[i])
    #             print("\n",separateByCout[i-1])
    #             new_word=str(separateByCout[i]).upper()
    #             Schema=str(response).replace(separateByCout[i],new_word)
    #             Schema=Schema.replace("!=","NOT LIKE")
    #             Schema=Schema.replace("=","LIKE")
    #             response=Schema
 
    
    for i in range(len(splitBySpace)):
        for j in range(len(separateByCout)):
            if str(splitBySpace[i]).replace("\'","") in str(separateByCout[j]).replace("\'",""):
                # tem_var=str(splitBySpace[i]).replace("\'","")
                # tem_var=tem_var.strip()
                # tem_var="\'"+tem_var+"%"+"\'"
                if splitBySpace[i-1]=="!=":
                    tem_var2=str(splitBySpace[i-1]).replace("!=","NOT LIKE")
                    splitBySpace[i-1]=tem_var2
                else:
                    tem_var2=str(splitBySpace[i-2]).replace("=","LIKE")
                    tem_var2=str(splitBySpace[i-1]).replace("=","LIKE")
                    # print("********",tem_var2)
                    splitBySpace[i-1]=tem_var2
                # splitBySpace[i]=tem_var

        
                
    #To give Duble couts for Digits            
    # response=response.upper()      
    

    # for i in range(len(splitBySpace)):
    #     if splitBySpace[i].isdigit():
    #         if splitBySpace[i-1]=="LIKE" or splitBySpace[i-2]=="LIKE":
    #             if number_length!=-1:      
    #                 for j in positionOFThatNumber:
    #                     tem_number=seperatedBySpace_query[j]
    #                     temp_var="\'"+tem_number+"\'"
    #                     splitBySpace[i]=temp_var
    #             else:
    #                     temp_var="\'"+splitBySpace[i]+"\'"
    #                     splitBySpace[i]=temp_var
    
    
    

    length1=0
    flag=False
    var1= splitBySpace      
    #To add "%" Sign After LIKE operator                  
    for i in range(len(var1)):
        if "LIKE"== var1[i] or "NOT LIKE"== var1[i]:
            for j in range(i,len(var1)):
                if "\'" in var1[j]:
                    var3=var1[j].replace("\'"," 1 ")
                    var2=var3.split(" ")
                    for k in var2:
                        if k == "1":
                            length1=length1+1
                    if length1==1:
                        tem_var1=var2.index("1")
                        if flag==True:
                            tem_var4=var1[j].replace("\'","")
                            tem_var4=tem_var4+"%"+"\'"
                            var1[j]=tem_var4
                            length1=0
                            flag=False
                            break
                        if tem_var1==1:
                            length1=0
                            flag=True
                            pass
                    if length1==2:
                        temp_var=var1[j].replace("\'","")
                        temp_var="\'"+temp_var+"%"+"\'"
                        var1[j]=temp_var
                        length1=0
                        break
                    
    # combine all Final Query
    response2=""
    # var1=['SELECT', 'MD', 'FROM', 'COMPANY_MASTER', 'WHERE', 'COMPANY_NAME', 'LIKE', "521"]
    

        # print("******pisition_of_like",pisition_of_like)
    for i in range(len(splitBySpace)): 
        response2=response2+splitBySpace[i]+" "
    # print("11")

    # print("\nsplitBySpace--------------->>>>>>>>>>>>>>>  ",splitBySpace)
    query_answer=[]
    try:
        query_answer=db.run(response2.upper())
        
        query_answer=query_answer.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
        query_answer=query_answer.replace("Decimal","")  
    except:#coloum_name_of_textDatatype,query_answer
        query_answer=change_coloum_name_befor_like(splitBySpace,coloum_name_of_textDatatype,table)
    
    if len(query_answer)==0:  
        query_answer=change_coloum_name_befor_like(splitBySpace,coloum_name_of_textDatatype,table)
    else:
        print("\nAfter Poressing Final Query--------------->>>>>>>>>>>>>>>  ",response2)
    print("\n\nquery_answer------------->>>>>>>>>>>>   ",query_answer)
    return query_answer
        
        
        
        
        
        
def change_coloum_name_befor_like(splitBySpace,coloum_name_of_textDatatype,table):
    query_answer=[]
    db = SQLDatabase.from_uri(connection_url,include_tables=[table],sample_rows_in_table_info=0)

    response2=""
    
        # print("13")
        # pisition_of_like=splitBySpace.index('LIKE')
    pisition_of_like=[]
    for k in range(len(splitBySpace)):
        if splitBySpace[k]=='LIKE':
            pisition_of_like.append(k)
    try:
        if len(pisition_of_like)==1:
            # print("***************** in if")
            
            for j in range(len(coloum_name_of_textDatatype)):
                tem_falg=False
                for m in range(len(pisition_of_like)):
                    splitBySpace[pisition_of_like[m]-1]=coloum_name_of_textDatatype[j]
                    for i in range(len(splitBySpace)): 
                        response2=response2+splitBySpace[i]+" "
                    # print("\nAfter Poressing Final Query userd diffrerent coloum name--------------->>>>>>>>>>>>>>>  ",response2)
                    query_answer=db.run(response2.upper())

                    query_answer=query_answer.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
                    query_answer=query_answer.replace("Decimal","")  
                    if len(query_answer)!=0:    
                        # print("14")
                        print("\nAfter Poressing Final11111111111 Query--------------->>>>>>>>>>>>>>>  ",response2)
                        response2=""
                        tem_falg=True
                        break
                    response2=""
                if tem_falg==True:
                    break     
        else:
            if len(pisition_of_like)==2:
                for j in range(len(coloum_name_of_textDatatype)):
                    tem_falg_1=False
                    for m in range(len(pisition_of_like)):
                        tem_falg_2=False
                        splitBySpace[pisition_of_like[m]-1]=coloum_name_of_textDatatype[j]
                        for l in range(len(coloum_name_of_textDatatype)):
                            splitBySpace[pisition_of_like[m+1]-1]=coloum_name_of_textDatatype[l]
                            for i in range(len(splitBySpace)): 
                                response2=response2+splitBySpace[i]+" "
                        # print("\nAfter Poressing Final Query userd diffrerent coloum name--------------->>>>>>>>>>>>>>>  ",response2)
                            query_answer=db.run(response2.upper())

                            query_answer=query_answer.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
                            query_answer=query_answer.replace("Decimal","")  
                            if len(query_answer)!=0:    
                                # print("14")
                                print("\nAfter Poressing Final11111111111 Query--------------->>>>>>>>>>>>>>>  ",response2)
                                response2=""
                                tem_falg_1=True
                                tem_falg_2=True
                                break
                            response2=""
                        if tem_falg_2==True:
                            break  
                    if tem_falg_1==True:
                            break 
                
    except:
        for i in range(len(splitBySpace)): 
            response2=response2+splitBySpace[i]+" "

        try:
            query_answer=db.run(response2.upper())
            
            query_answer=query_answer.replace("[","").replace("]","").replace("(","").replace(")","").replace(",,",",")
            query_answer=query_answer.replace("Decimal","")  
        except:
            query_answer="Error9"
        # print("\n\nquery_answer------------->>>>>>>>>>>>   ",query_answer)
        # print("\n\n///////////////////////   ",query_answer)
        # print("\n\n///////////////////////   ",len(query_answer))
        print("\nAfter Poressing Final Query--------------->>>>>>>>>>>>>>>  ",response2)
    return query_answer

    













def remove_duplicate(list_1):
    tem_list=[]
    for item in range(1,len(list_1),3):
        if list_1[item] not in tem_list:
            tem_list.append(list_1[item-1])
            tem_list.append(list_1[item])
            tem_list.append(list_1[item+1])
    return tem_list
            






def get_only_Sql_Qury(table,query):
    # print("table******",table)
    # print("table******",query)
    
    # db = SQLDatabase.from_uri(connection_url,include_tables=['COMPANY_MASTER','HOUSE_MST','Balancesheet'],sample_rows_in_table_info=5)
    db = SQLDatabase.from_uri(connection_url,include_tables=[table],sample_rows_in_table_info=0)
    # db = SQLDatabase.from_uri("sqlite:///trainee_database.db",include_tables=['Company_Master','sheet'])#,'Company_Master','Balancesheet_backup'
    llm = AI21(temperature=0)
    # query=request.POST.get('question') 
    # print("\n\n-------------------------",db.get_table_info())
    table_structure=db.get_table_info()
    table_structure=table_structure.replace("\t","").replace("\n","").split(",")

    db_chain = SQLDatabaseChain.from_llm(llm, db,use_query_checker=True,return_sql=True)# verbose=True,
    response=db_chain(query)
    # print("\n\n\nBefor Poressing Query------------------->>>>>>>>>   ",str(response['result']).upper())
    # print("\n\n***********--*-----++++++++response",response)
    response=str(response['result']).upper()
    return response
    













# Chain Invoke Method


     # chain = create_sql_query_chain(AI21(temperature=0.7), db)
     # response=response['result'].replace("LIMITED", "LTD")
      # table=db.get_table_names()
     # print("++++++++++++++++++db.get_table_info",db.get_table_info(table))
     # response =chain.invoke({"question":query})
     # print("-----------------",response)ws
     
     
     
     
""" 
# Limitation 

1. Coloum name compulasary with "_" ex:---- share_capital 

2. all value should be in capital only

3. composite key not allow jar the vay chi asel tar combination madhe 1 pahije primary key

4. tata consultany sarkha nav parat  dusrya kontya table madhe nko

5. primary key name and f key name must be same 



"""   





# CREATE TABLE IF NOT EXISTS public.company_master
# (
#     company_code integer NOT NULL,
#     bse_code integer NULL,
#     bse_company_name text  NULL,
#     bse_group text  NULL,
#     scrip_type text  NULL,
#     company text  NULL,
#     industry_code integer,
#     house_code integer,
#     nse_symbol text  NULL,
#     nse_series text  NULL,
#     isin text  NULL,
#     reuters_code text  NULL,
#     company_short_name text  NULL,
#     chairman text  NULL,
#     md text  NULL,
#     company_secretary text  NULL,
#     inception_month text  NULL,
#     inception_year text  NULL,
#     bloomberg_code text  NULL,
#     status text  NULL,
#     listing text  NULL,
#     sublisting text  NULL,
#     CONSTRAINT company_code PRIMARY KEY (company_code)
# )









# CREATE TABLE INDUSTRY_MST(
# 	IND_CODE integer NULL,
# 	INDUSTRY text NULL,
# 	Ind_ShortName text NULL,
# 	Sector text NULL,
# 	FLAG text NULL,
# 	DOE TIMESTAMP NULL,
# 	DONEBY integer NULL,
# 	DELETED text NULL,
# 	Sector_Code integer NULL
# )



# CREATE TABLE HOUSE_MST(
    
# 	HOUSE_CODE integer NULL,
# 	HOUSE text NULL,
# 	FLAG text NULL,
# 	DOE date NULL,
# 	DONEBY integer NULL,
# 	DELETED text NULL,
# )