from django.contrib import admin
from django.urls import path
from django.conf import settings
from OpenAi import views 
from django.conf.urls.static import static

urlpatterns = [
    # path('',views.upload),
    # path('home/',views.home,),
    path('',views.Home,name="home"),
    path('client_before/',views.Client_before,name="client_before"),
    path('client_after/',views.Client_after,name="client_after"),
    path('database_before/',views.database_before,name="database_before"),
    path('database_after/',views.database_after,name="database_after"),
    path('get_company/',views.get_company,name="get_company"),
    # path('database_page_load/',views.database_page_load,name="database_page_load"),
    path('Admin_before/',views.Admin_before,name="Admin_before"),
    path('Admin_after/',views.Admin_after,name="Admin_after"),
    path('get_vector/',views.get_vector,name="get_vector"),
    # path('pdf/',views.PDFView.as_view(),name="pdf_view"),
    # path('chatbot/',views.chatbot,name='chatbot'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

