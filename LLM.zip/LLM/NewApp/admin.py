from django.contrib import admin

from .models import Balance,Post

class MemberAdmin(admin.ModelAdmin):
  list_display = ('company_code' ,'company_name', 'no_months', 'yrc', 'share_capital', 'equity_iss' ,    'equity_paidup'  ,   'adj_equity',     'pref_capital'  ,   'face_value' ,    'no_equity_paidup'   ,  'no_equity_subscribed'  ,   'equity_subscribed',     'equity_callup'    , 'resrv_surp'  ,   'share_premium'  ,   'capital_reserve'  ,   'profit_loss' )
  
admin.site.register(Balance, MemberAdmin)


admin.site.register(Post)